<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Password;
use Illuminate\View\View;

class AuthController extends Controller
{
    public function showLogin(): View
    {
        return view('auth.login');
    }

    public function login(Request $request): RedirectResponse
    {
        $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required', 'string'],
        ]);

        if (Auth::attempt(
            ['email' => $request->email, 'password' => $request->password],
            $request->boolean('remember'),
        )) {
            $request->session()->regenerate();

            return redirect()->intended(route('dashboard'));
        }

        return back()->withErrors([
            'email' => 'Email atau password salah.',
        ])->withInput();
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email'],
            'role' => ['required', Rule::in(['pasien', 'dokter', 'apoteker', 'suster'])],
            'current_password' => ['required', 'string'],
            'registration_code' => ['nullable', 'string', 'max:100'],
            'password' => ['required', 'confirmed', Password::min(10)],
        ]);

        $user = User::query()
            ->where('email', $validated['email'])
            ->where('role', $validated['role'])
            ->first();

        if (! $user) {
            return back()->withErrors([
                'reset_email' => 'Email atau peran tidak cocok dengan akun yang terdaftar.',
            ])->withInput([
                'reset_email' => $validated['email'],
                'reset_role' => $validated['role'],
            ]);
        }

        if (! Hash::check($validated['current_password'], $user->password)) {
            return back()->withErrors([
                'current_password' => 'Kata sandi saat ini tidak cocok.',
            ])->withInput([
                'reset_email' => $validated['email'],
                'reset_role' => $validated['role'],
            ]);
        }

        if ($validated['role'] !== 'pasien') {
            $expectedCode = config('clinic.registration_codes.'.$validated['role']);

            if (! is_string($expectedCode) || $expectedCode === '' || ! hash_equals($expectedCode, $validated['registration_code'] ?? '')) {
                return back()->withErrors([
                    'registration_code' => 'Kode verifikasi staf tidak valid. Hubungi administrasi klinik.',
                ])->withInput([
                    'reset_email' => $validated['email'],
                    'reset_role' => $validated['role'],
                ]);
            }
        }

        $user->update(['password' => Hash::make($validated['password'])]);

        return redirect()->route('login')->with('success', 'Kata sandi berhasil diganti. Silakan masuk dengan kata sandi baru.');
    }

    public function showRegister(): View
    {
        return view('auth.register');
    }

    public function register(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', 'unique:users,email'],
            'phone' => ['nullable', 'string', 'max:20'],
            'role' => ['required', Rule::in(['pasien', 'dokter', 'apoteker', 'suster'])],
            'national_id' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', 'digits:16'],
            'date_of_birth' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', 'date', 'before:today'],
            'gender' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', Rule::in(['Laki-laki', 'Perempuan'])],
            'address' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', 'string', 'max:2000'],
            'emergency_contact_name' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', 'string', 'max:255'],
            'emergency_contact_phone' => [Rule::requiredIf($request->input('role') === 'pasien'), 'nullable', 'string', 'max:20'],
            'blood_type' => ['nullable', Rule::in(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'])],
            'medical_history' => ['nullable', 'string', 'max:4000'],
            'staff_number' => [
                Rule::requiredIf($request->input('role') !== 'pasien'),
                'nullable',
                'string',
                'max:50',
                Rule::unique('users', 'staff_number')->where('role', $request->input('role')),
            ],
            'registration_code' => [
                Rule::requiredIf($request->input('role') !== 'pasien'),
                'nullable',
                'string',
                'max:100',
            ],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
        ]);

        if ($validated['role'] === 'pasien') {
            $nationalIdHash = User::nationalIdHash($validated['national_id']);

            if (User::query()->where('national_id_hash', $nationalIdHash)->exists()) {
                return back()->withErrors([
                    'national_id' => 'NIK sudah terdaftar.',
                ])->withInput($request->except(['password', 'password_confirmation', 'registration_code']));
            }
        }

        if ($validated['role'] !== 'pasien') {
            $expectedCode = config('clinic.registration_codes.'.$validated['role']);

            if (! is_string($expectedCode) || $expectedCode === '' || ! hash_equals($expectedCode, $validated['registration_code'])) {
                return back()->withErrors([
                    'registration_code' => 'Kode pendaftaran staf tidak valid. Hubungi administrasi klinik untuk mendapatkan kode resmi.',
                ]);
            }
        }

        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'phone' => $validated['phone'] ?? null,
            'role' => $validated['role'],
            'staff_number' => $validated['role'] === 'pasien' ? null : $validated['staff_number'],
            'national_id' => $validated['role'] === 'pasien' ? $validated['national_id'] : null,
            'national_id_hash' => $validated['role'] === 'pasien' ? User::nationalIdHash($validated['national_id']) : null,
            'date_of_birth' => $validated['role'] === 'pasien' ? $validated['date_of_birth'] : null,
            'gender' => $validated['role'] === 'pasien' ? $validated['gender'] : null,
            'address' => $validated['role'] === 'pasien' ? $validated['address'] : null,
            'emergency_contact_name' => $validated['role'] === 'pasien' ? $validated['emergency_contact_name'] : null,
            'emergency_contact_phone' => $validated['role'] === 'pasien' ? $validated['emergency_contact_phone'] : null,
            'blood_type' => $validated['role'] === 'pasien' ? ($validated['blood_type'] ?? null) : null,
            'medical_history' => $validated['role'] === 'pasien' ? ($validated['medical_history'] ?? null) : null,
            'password' => Hash::make($validated['password']),
        ]);

        Auth::login($user);

        return redirect()->route('dashboard')->with('success', 'Akun berhasil dibuat. Selamat datang di Klinik UNPAM.');
    }

    public function logout(Request $request): RedirectResponse
    {
        Auth::logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('landing');
    }
}
