<?php

namespace App\Http\Controllers;

use App\Models\Medicine;
use App\Models\Payment;
use App\Models\Prescription;
use App\Models\PrescriptionItem;
use App\Models\User;
use App\Models\Visit;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ClinicWorkflowController extends Controller
{
    public function dashboard(Request $request): View
    {
        $user = $this->currentUser($request);

        return view('dashboard', $this->dashboardData($user));
    }

    public function workflow(Request $request): Response
    {
        $user = $this->currentUser($request);

        return response()
            ->view('components.clinic-workflow', $this->dashboardData($user))
            ->header('Cache-Control', 'no-store, private');
    }

    public function storeVisit(Request $request): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'pasien', 403);

        $validated = $request->validate([
            'service' => ['required', Rule::in(['Poli Umum', 'Poli Gigi', 'Poli KIA', 'Poli Ortopedi'])],
            'complaint' => ['nullable', 'string', 'max:2000'],
        ]);

        $queueNumber = DB::transaction(function () use ($user, $validated): string {
            $queueDate = now()->toDateString();
            $sequence = (int) Visit::query()
                ->where('service', $validated['service'])
                ->whereDate('queue_date', $queueDate)
                ->lockForUpdate()
                ->max('queue_sequence') + 1;
            $queueCode = $this->queueCode($validated['service']);

            Visit::query()->create([
                'patient_id' => $user->id,
                'queue_number' => $sequence.$queueCode,
                'queue_sequence' => $sequence,
                'queue_date' => $queueDate,
                'service' => $validated['service'],
                'complaint' => $validated['complaint'] ?? null,
                'status' => 'menunggu_dokter',
            ]);

            return $sequence.$queueCode;
        });

        return redirect()->route('dashboard')->with('success', 'Nomor antrean '.$queueNumber.' tersimpan. Data pasien sudah masuk ke daftar dokter.');
    }

    public function updateVisitStatus(Request $request, Visit $visit): RedirectResponse
    {
        $user = $this->currentUser($request);
        $validated = $request->validate([
            'status' => ['required', Rule::in(['dibatalkan', 'menunggu_dokter', 'dipanggil', 'konsultasi', 'selesai'])],
        ]);
        $nextStatus = $validated['status'];

        if ($user->role === 'pasien') {
            abort_unless($visit->patient_id === $user->id, 403);
            abort_unless($nextStatus === 'dibatalkan' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true), 409);

            $visit->update(['status' => 'dibatalkan']);
        } elseif ($user->role === 'dokter') {
            if ($nextStatus === 'dipanggil' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true) && $visit->assigned_doctor_id === null) {
                $visit->update([
                    'status' => 'dipanggil',
                    'assigned_doctor_id' => $user->id,
                    'called_at' => now(),
                ]);
            } elseif ($nextStatus === 'konsultasi' && $visit->status === 'dipanggil' && $visit->assigned_doctor_id === $user->id) {
                $visit->update([
                    'status' => 'konsultasi',
                    'consultation_started_at' => now(),
                ]);
            } elseif ($nextStatus === 'selesai' && $visit->status === 'konsultasi' && $visit->assigned_doctor_id === $user->id && $visit->prescription()->exists()) {
                $visit->update(['status' => 'selesai', 'completed_at' => now()]);
            } else {
                abort(409, 'Status antrean sudah berubah atau tidak dapat dilanjutkan.');
            }
        } else {
            abort(403);
        }

        return redirect()->route('dashboard')->with('success', 'Status kunjungan berhasil diperbarui.');
    }

    public function storePrescription(Request $request, Visit $visit): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'dokter', 403);
        abort_unless($visit->status === 'konsultasi' && $visit->assigned_doctor_id === $user->id, 403);

        $validated = $request->validate([
            'items' => ['required', 'array', 'min:1', 'max:10'],
            'items.*.medicine_id' => ['required', 'integer', 'distinct', 'exists:medicines,id'],
            'items.*.quantity' => ['required', 'integer', 'min:1', 'max:100'],
            'items.*.dosage' => ['required', 'string', 'max:255'],
        ]);

        abort_if($visit->prescription()->exists(), 409, 'Resep untuk kunjungan ini sudah dicatat.');

        DB::transaction(function () use ($validated, $user, $visit): void {
            $prescription = $visit->prescription()->create([
                'doctor_id' => $user->id,
                'medicine' => 'Resep terstruktur',
            ]);

            foreach ($validated['items'] as $item) {
                $medicine = Medicine::query()->whereKey($item['medicine_id'])->where('is_active', true)->firstOrFail();

                $prescription->items()->create([
                    'medicine_id' => $medicine->id,
                    'quantity' => $item['quantity'],
                    'dosage' => $item['dosage'],
                    'unit_price' => $medicine->unit_price,
                ]);
            }
        });

        return redirect()->route('dashboard')->with('success', 'Resep berhasil dikirim ke antrean apotek.');
    }

    public function updatePrescriptionStatus(Request $request, Prescription $prescription): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'apoteker', 403);

        $validated = $request->validate(['status' => ['required', Rule::in(['siap_diambil', 'diserahkan'])]]);

        if ($validated['status'] === 'siap_diambil') {
            abort_unless($prescription->status === 'diproses', 409);

            DB::transaction(function () use ($prescription): void {
                $lockedPrescription = Prescription::query()->whereKey($prescription->id)->lockForUpdate()->firstOrFail();
                abort_unless($lockedPrescription->status === 'diproses', 409);

                $amount = $lockedPrescription->items()->get()->sum(
                    fn (PrescriptionItem $item): float => (float) $item->unit_price * $item->quantity,
                );

                $lockedPrescription->update(['status' => 'siap_diambil']);
                $lockedPrescription->visit->payment()->firstOrCreate([], [
                    'amount' => $amount,
                    'status' => 'belum_bayar',
                ]);
            });
        } else {
            abort_unless($prescription->status === 'siap_diambil', 409);
            abort_unless($prescription->visit->payment?->status === 'dibayar', 409, 'Pembayaran perlu dicatat sebelum obat diserahkan.');

            $prescription->update(['status' => 'diserahkan']);
        }

        return redirect()->route('dashboard')->with('success', 'Status resep berhasil diperbarui.');
    }

    public function processPrescription(Request $request, Prescription $prescription): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'apoteker', 403);

        $result = DB::transaction(function () use ($prescription): array {
            $lockedPrescription = Prescription::query()
                ->whereKey($prescription->id)
                ->lockForUpdate()
                ->firstOrFail();

            abort_unless(in_array($lockedPrescription->status, ['menunggu', 'stok_tidak_cukup'], true), 409);

            $items = $lockedPrescription->items()->orderBy('medicine_id')->get();
            $medicines = Medicine::query()
                ->whereIn('id', $items->pluck('medicine_id'))
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            $shortages = [];

            foreach ($items as $item) {
                $medicine = $medicines->get($item->medicine_id);

                if ($medicine->stock < $item->quantity) {
                    $shortages[] = $medicine->name.' (butuh '.$item->quantity.', tersedia '.$medicine->stock.')';
                }
            }

            if ($shortages !== []) {
                $lockedPrescription->update(['status' => 'stok_tidak_cukup']);

                return ['shortages' => $shortages];
            }

            foreach ($items as $item) {
                $medicines->get($item->medicine_id)->decrement('stock', $item->quantity);
            }

            $lockedPrescription->update(['status' => 'diproses']);

            return ['shortages' => []];
        });

        if ($result['shortages'] !== []) {
            return redirect()->route('dashboard')->with('error', 'Stok belum cukup: '.implode('; ', $result['shortages']));
        }

        return redirect()->route('dashboard')->with('success', 'Stok berhasil dialokasikan untuk resep.');
    }

    public function recordPayment(Request $request, Payment $payment): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'apoteker', 403);

        DB::transaction(function () use ($payment, $user): void {
            $lockedPayment = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();
            abort_unless($lockedPayment->status === 'belum_bayar', 409);
            abort_unless($lockedPayment->visit->prescription?->status === 'siap_diambil', 409);

            $lockedPayment->update([
                'status' => 'dibayar',
                'method' => 'tunai',
                'processed_by' => $user->id,
                'paid_at' => now(),
            ]);
        });

        return redirect()->route('dashboard')->with('success', 'Pembayaran tunai tercatat. Obat dapat diserahkan kepada pasien.');
    }

    public function restockMedicine(Request $request, Medicine $medicine): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'apoteker', 403);

        $validated = $request->validate(['quantity' => ['required', 'integer', 'min:1', 'max:1000']]);

        $medicine->increment('stock', $validated['quantity']);

        return redirect()->route('dashboard')->with('success', 'Stok '.$medicine->name.' berhasil diperbarui.');
    }

    public function storeMedicine(Request $request): RedirectResponse
    {
        $user = $this->currentUser($request);
        abort_unless($user->role === 'apoteker', 403);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255', 'unique:medicines,name'],
            'form' => ['required', 'string', 'max:60'],
            'strength' => ['required', 'string', 'max:100'],
            'unit' => ['required', 'string', 'max:40'],
            'stock' => ['required', 'integer', 'min:0', 'max:1000000'],
            'unit_price' => ['required', 'numeric', 'min:0.01', 'max:9999999999.99'],
        ]);

        $medicine = Medicine::query()->create([
            ...$validated,
            'is_active' => true,
        ]);

        return redirect()->route('dashboard')->with('success', 'Obat '.$medicine->name.' berhasil ditambahkan ke persediaan.');
    }

    /** @return array<string, mixed> */
    private function dashboardData(User $user): array
    {
        $visitQuery = Visit::query()->with(['patient', 'doctor', 'prescription', 'payment'])->latest();

        if ($user->role === 'pasien') {
            $visitQuery->whereBelongsTo($user, 'patient');
        } elseif ($user->role === 'suster') {
            $visitQuery->whereDate('queue_date', now()->toDateString());
        } elseif (! in_array($user->role, ['dokter', 'suster', 'apoteker'], true)) {
            $visitQuery->whereRaw('1 = 0');
        }

        $prescriptionQuery = Prescription::query()->with(['visit.patient', 'visit.payment', 'doctor', 'items.medicine'])->latest();

        if ($user->role === 'dokter') {
            $prescriptionQuery->whereBelongsTo($user, 'doctor');
        } elseif ($user->role !== 'apoteker') {
            $prescriptionQuery->whereRaw('1 = 0');
        }

        $visitCounts = [
            'total' => (clone $visitQuery)->count(),
            'menunggu_verifikasi' => 0,
            'menunggu_dokter' => (clone $visitQuery)->whereIn('status', ['menunggu_verifikasi', 'menunggu_dokter'])->count(),
            'konsultasi' => (clone $visitQuery)->where('status', 'konsultasi')->count(),
            'selesai' => (clone $visitQuery)->where('status', 'selesai')->count(),
            'riwayat' => $user->role === 'pasien'
                ? (clone $visitQuery)->whereIn('status', ['selesai', 'dibatalkan'])->count()
                : 0,
        ];
        $prescriptionCounts = [
            'total' => (clone $prescriptionQuery)->count(),
            'menunggu' => (clone $prescriptionQuery)->where('status', 'menunggu')->count(),
            'diproses' => (clone $prescriptionQuery)->where('status', 'diproses')->count(),
            'siap_diambil' => (clone $prescriptionQuery)->where('status', 'siap_diambil')->count(),
        ];

        $visits = $user->role === 'pasien'
            ? (clone $visitQuery)->whereIn('status', ['menunggu_verifikasi', 'menunggu_dokter', 'dipanggil', 'konsultasi'])->latest()->limit(30)->get()
            : (clone $visitQuery)
                ->when($user->role !== 'suster', fn ($query) => $query->limit(30))
                ->get();
        $visitHistory = $user->role === 'pasien'
            ? (clone $visitQuery)->whereIn('status', ['selesai', 'dibatalkan'])->latest()->limit(100)->get()
            : collect();
        $queueCallEstimates = [];

        if ($user->role === 'pasien') {
            $patientWaitingVisits = $visits->where('status', 'menunggu_dokter');
            $queueDates = $patientWaitingVisits
                ->map(fn (Visit $visit): ?string => $visit->queue_date?->toDateString())
                ->filter()
                ->unique()
                ->values();
            $services = $patientWaitingVisits->pluck('service')->unique()->values();
            $activeQueueAhead = Visit::query()
                ->whereIn('service', $services)
                ->whereIn('queue_date', $queueDates)
                ->whereIn('status', ['menunggu_dokter', 'dipanggil', 'konsultasi'])
                ->orderBy('service')
                ->orderBy('queue_date')
                ->orderBy('queue_sequence')
                ->get(['service', 'queue_date', 'queue_sequence', 'status']);

            foreach ($visits as $visit) {
                if ($visit->status === 'dipanggil') {
                    $queueCallEstimates[$visit->id] = 'Dokter memanggil Anda sekarang'.($visit->called_at ? ' ('.$visit->called_at->format('H:i').')' : '.');
                } elseif ($visit->status === 'konsultasi') {
                    $queueCallEstimates[$visit->id] = 'Anda sedang dalam pemeriksaan dokter.';
                } elseif ($visit->status === 'menunggu_dokter') {
                    $queueDate = $visit->queue_date?->toDateString();
                    $aheadCount = $activeQueueAhead->filter(
                        fn (Visit $queuedVisit): bool => $queuedVisit->service === $visit->service
                            && $queuedVisit->queue_date?->toDateString() === $queueDate
                            && $queuedVisit->queue_sequence < $visit->queue_sequence,
                    )->count();
                    $estimatedCallTime = now()->addMinutes($aheadCount * 15);
                    $queueCallEstimates[$visit->id] = $aheadCount === 0
                        ? 'Anda berikutnya; perkiraan dipanggil segera.'
                        : 'Perkiraan dipanggil sekitar '.$estimatedCallTime->format('H:i').' ('.$aheadCount.' antrean sebelum Anda).';
                }
            }
        }

        return [
            'user' => $user,
            'roleLabel' => $user->roleLabel(),
            'visits' => $visits,
            'visitHistory' => $visitHistory,
            'queueCallEstimates' => $queueCallEstimates,
            'prescriptions' => (clone $prescriptionQuery)->limit(30)->get(),
            'medicines' => in_array($user->role, ['dokter', 'apoteker'], true)
                ? Medicine::query()->where('is_active', true)->orderBy('name')->get()
                : collect(),
            'visitCounts' => $visitCounts,
            'prescriptionCounts' => $prescriptionCounts,
        ];
    }

    private function currentUser(Request $request): User
    {
        $user = $request->user();
        abort_unless($user instanceof User, 403);

        return $user;
    }

    private function queueCode(string $service): string
    {
        return match ($service) {
            'Poli Umum' => 'A',
            'Poli Gigi' => 'G',
            'Poli KIA' => 'K',
            'Poli Ortopedi' => 'O',
            default => throw new \InvalidArgumentException('Poli antrean tidak dikenali.'),
        };
    }
}
