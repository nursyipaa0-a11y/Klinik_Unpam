<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProfileController extends Controller
{
    public function show(Request $request): View
    {
        $user = $request->user();
        abort_unless($user instanceof User, 403);

        return view('profile', [
            'user' => $user,
            'roleLabel' => $user->roleLabel(),
        ]);
    }

    public function update(Request $request): RedirectResponse
    {
        $user = $request->user();
        abort_unless($user instanceof User, 403);

        $rules = [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'max:255', Rule::unique('users', 'email')->ignore($user->id)],
            'phone' => ['nullable', 'string', 'max:20'],
        ];

        if ($user->role === 'pasien') {
            $rules = array_merge($rules, [
                'national_id' => ['required', 'digits:16'],
                'date_of_birth' => ['required', 'date', 'before:today'],
                'gender' => ['required', Rule::in(['Laki-laki', 'Perempuan'])],
                'address' => ['required', 'string', 'max:2000'],
                'emergency_contact_name' => ['required', 'string', 'max:255'],
                'emergency_contact_phone' => ['required', 'string', 'max:20'],
                'blood_type' => ['nullable', Rule::in(['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'])],
                'medical_history' => ['nullable', 'string', 'max:4000'],
            ]);
        }

        $validated = $request->validate($rules);

        if ($user->role === 'pasien') {
            $nationalIdHash = User::nationalIdHash($validated['national_id']);

            if (User::query()->where('national_id_hash', $nationalIdHash)->whereKeyNot($user->id)->exists()) {
                return back()->withErrors([
                    'national_id' => 'NIK sudah terdaftar.',
                ])->withInput($request->except(['password', 'password_confirmation']));
            }

            $validated['national_id_hash'] = $nationalIdHash;
        }

        $user->update($validated);

        return redirect()->route('profile')->with('success', 'Data pengguna berhasil diperbarui.');
    }
}
