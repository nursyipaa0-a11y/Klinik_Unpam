<?php

namespace App\Models;

use Database\Factories\MedicineFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Medicine extends Model
{
    /** @use HasFactory<MedicineFactory> */
    use HasFactory;

    protected $fillable = ['name', 'form', 'strength', 'unit', 'stock', 'unit_price', 'is_active'];

    protected function casts(): array
    {
        return ['stock' => 'integer', 'unit_price' => 'decimal:2', 'is_active' => 'boolean'];
    }

    public function prescriptionItems(): HasMany
    {
        return $this->hasMany(PrescriptionItem::class);
    }
}
