<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable([
    'name',
    'email',
    'phone',
    'role',
    'staff_number',
    'national_id',
    'national_id_hash',
    'date_of_birth',
    'gender',
    'address',
    'emergency_contact_name',
    'emergency_contact_phone',
    'blood_type',
    'medical_history',
    'password',
])]
#[Hidden([
    'password',
    'remember_token',
    'national_id',
    'national_id_hash',
    'date_of_birth',
    'gender',
    'address',
    'emergency_contact_name',
    'emergency_contact_phone',
    'blood_type',
    'medical_history',
])]
class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'national_id' => 'encrypted',
            'date_of_birth' => 'date',
        ];
    }

    public static function nationalIdHash(string $nationalId): string
    {
        return hash_hmac('sha256', $nationalId, (string) config('app.key'));
    }

    public function roleLabel(): string
    {
        return match ($this->role) {
            'dokter' => 'Dokter',
            'apoteker' => 'Apoteker',
            'suster' => 'Perawat',
            default => 'Pasien',
        };
    }
}
