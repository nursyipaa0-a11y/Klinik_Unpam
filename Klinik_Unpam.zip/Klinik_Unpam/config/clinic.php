<?php

return [
    'registration_codes' => [
        'dokter' => env('CLINIC_DOKTER_REGISTRATION_CODE'),
        'apoteker' => env('CLINIC_APOTEKER_REGISTRATION_CODE'),
        'suster' => env('CLINIC_SUSTER_REGISTRATION_CODE'),
    ],
];
