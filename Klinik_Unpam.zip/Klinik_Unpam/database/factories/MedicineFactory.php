<?php

namespace Database\Factories;

use App\Models\Medicine;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Medicine>
 */
class MedicineFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'name' => fake()->unique()->words(2, true),
            'form' => 'Tablet',
            'strength' => '500 mg',
            'unit' => 'tablet',
            'stock' => 100,
            'unit_price' => 5000,
            'is_active' => true,
        ];
    }
}
