<?php

namespace Database\Factories;

use App\Models\Payment;
use App\Models\Visit;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Payment>
 */
class PaymentFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'visit_id' => Visit::factory(),
            'processed_by' => null,
            'amount' => 5000,
            'status' => 'belum_bayar',
            'method' => null,
            'paid_at' => null,
        ];
    }
}
