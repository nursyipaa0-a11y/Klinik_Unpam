<?php

namespace Database\Factories;

use App\Models\User;
use App\Models\Visit;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Visit>
 */
class VisitFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'patient_id' => User::factory()->state(['role' => 'pasien']),
            'assigned_doctor_id' => null,
            'queue_number' => 'Q-'.fake()->unique()->numerify('######'),
            'service' => fake()->randomElement(['Poli Umum', 'Poli Gigi', 'Poli KIA']),
            'complaint' => fake()->sentence(),
            'status' => 'menunggu_verifikasi',
            'verified_at' => null,
            'consultation_started_at' => null,
            'completed_at' => null,
        ];
    }
}
