<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('visits', function (Blueprint $table): void {
            $table->unsignedInteger('queue_sequence')->nullable()->after('queue_number');
            $table->date('queue_date')->nullable()->after('queue_sequence');
            $table->index(['service', 'queue_date', 'queue_sequence'], 'visits_service_queue_lookup_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('visits', function (Blueprint $table): void {
            $table->dropIndex('visits_service_queue_lookup_index');
            $table->dropColumn(['queue_sequence', 'queue_date']);
        });
    }
};
