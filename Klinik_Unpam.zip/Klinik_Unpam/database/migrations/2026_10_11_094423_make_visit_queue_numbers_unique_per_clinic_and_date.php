<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('visits', function (Blueprint $table): void {
            $table->dropUnique('visits_queue_number_unique');
            $table->unique(['service', 'queue_date', 'queue_sequence'], 'visits_service_date_sequence_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('visits', function (Blueprint $table): void {
            $table->dropUnique('visits_service_date_sequence_unique');
            $table->unique('queue_number');
        });
    }
};
