<?php

namespace Database\Seeders;

use App\Models\Medicine;
use Illuminate\Database\Seeder;

class MedicineCatalogSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $medicines = [
            ['name' => 'Paracetamol', 'form' => 'Tablet', 'strength' => '500 mg', 'unit' => 'tablet', 'stock' => 100, 'unit_price' => 3000],
            ['name' => 'Paracetamol Sirup', 'form' => 'Sirup', 'strength' => '120 mg/5 mL', 'unit' => 'botol', 'stock' => 100, 'unit_price' => 18000],
            ['name' => 'Amoxicillin', 'form' => 'Kapsul', 'strength' => '500 mg', 'unit' => 'kapsul', 'stock' => 100, 'unit_price' => 4500],
            ['name' => 'Oralit', 'form' => 'Serbuk sachet', 'strength' => '200 mL', 'unit' => 'sachet', 'stock' => 100, 'unit_price' => 2500],
            ['name' => 'Vitamin C', 'form' => 'Tablet', 'strength' => '500 mg', 'unit' => 'tablet', 'stock' => 100, 'unit_price' => 2000],
            ['name' => 'Cetirizine', 'form' => 'Tablet', 'strength' => '10 mg', 'unit' => 'tablet', 'stock' => 100, 'unit_price' => 3500],
            ['name' => 'Ambroxol Sirup', 'form' => 'Sirup', 'strength' => '15 mg/5 mL', 'unit' => 'botol', 'stock' => 2, 'unit_price' => 16000],
            ['name' => 'Ibuprofen', 'form' => 'Tablet', 'strength' => '200 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 1500],
            ['name' => 'Antasida', 'form' => 'Tablet kunyah', 'strength' => 'Sesuai label kemasan', 'unit' => 'tablet', 'stock' => 60, 'unit_price' => 1000],
            ['name' => 'CTM', 'form' => 'Tablet', 'strength' => '4 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 500],
            ['name' => 'Salbutamol', 'form' => 'Tablet', 'strength' => '2 mg', 'unit' => 'tablet', 'stock' => 30, 'unit_price' => 1000],
            ['name' => 'Zinc', 'form' => 'Tablet dispersibel', 'strength' => '20 mg', 'unit' => 'tablet', 'stock' => 40, 'unit_price' => 1500],
            ['name' => 'Amlodipine', 'form' => 'Tablet', 'strength' => '5 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 1500],
            ['name' => 'Omeprazole', 'form' => 'Kapsul', 'strength' => '20 mg', 'unit' => 'kapsul', 'stock' => 50, 'unit_price' => 2000],
            ['name' => 'Metformin', 'form' => 'Tablet', 'strength' => '500 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 1000],
            ['name' => 'Dextromethorphan', 'form' => 'Tablet', 'strength' => '15 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 1000],
            ['name' => 'Asam Mefenamat', 'form' => 'Tablet', 'strength' => '500 mg', 'unit' => 'tablet', 'stock' => 50, 'unit_price' => 1500],
        ];

        foreach ($medicines as $medicine) {
            Medicine::query()->firstOrCreate(
                ['name' => $medicine['name']],
                [...$medicine, 'is_active' => true],
            );
        }
    }
}
