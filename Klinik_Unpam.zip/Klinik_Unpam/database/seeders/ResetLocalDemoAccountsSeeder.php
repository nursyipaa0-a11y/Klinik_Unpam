<?php

namespace Database\Seeders;

use App\Models\Payment;
use App\Models\Prescription;
use App\Models\PrescriptionItem;
use App\Models\User;
use App\Models\Visit;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use RuntimeException;

class ResetLocalDemoAccountsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $connection = DB::connection();
        $isAllowedDatabase = $connection->getDriverName() === 'sqlite'
            || ($connection->getDriverName() === 'mysql' && $connection->getDatabaseName() === 'db_klinik');

        if (! App::environment('local', 'testing') || ! $isAllowedDatabase) {
            throw new RuntimeException('Reset akun demo hanya diizinkan di environment local/testing pada SQLite pengujian atau MySQL db_klinik.');
        }

        $accounts = [
            [
                'name' => 'Pasien Demo',
                'email' => 'pasien.demo@klinik-unpam.test',
                'role' => 'pasien',
                'password' => 'PasienDemo2026!',
                'phone' => '081200000001',
                'staff_number' => null,
            ],
            [
                'name' => 'Dokter Demo',
                'email' => 'dokter.demo@klinik-unpam.test',
                'role' => 'dokter',
                'password' => 'DokterDemo2026!',
                'phone' => '081200000002',
                'staff_number' => 'DOK-DEMO-001',
            ],
            [
                'name' => 'Apoteker Demo',
                'email' => 'apoteker.demo@klinik-unpam.test',
                'role' => 'apoteker',
                'password' => 'ApotekerDemo2026!',
                'phone' => '081200000003',
                'staff_number' => 'APT-DEMO-001',
            ],
            [
                'name' => 'Perawat Demo',
                'email' => 'perawat.demo@klinik-unpam.test',
                'role' => 'suster',
                'password' => 'PerawatDemo2026!',
                'phone' => '081200000004',
                'staff_number' => 'SUS-DEMO-001',
            ],
        ];

        DB::transaction(function () use ($accounts): void {
            PrescriptionItem::query()->delete();
            Prescription::query()->delete();
            Payment::query()->delete();
            Visit::query()->delete();
            User::query()->delete();

            foreach ($accounts as $account) {
                User::query()->create([
                    ...$account,
                    'password' => Hash::make($account['password']),
                ]);
            }
        });
    }
}
