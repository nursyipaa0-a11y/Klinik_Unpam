(() => {
    const updatePrescriptionItemCount = (form) => {
        const list = form.querySelector('[data-prescription-items]');
        const addButton = form.querySelector('[data-add-prescription-item]');
        const itemCount = list.querySelectorAll('.prescription-item-row').length;
        const maximumItems = Number(form.dataset.maxPrescriptionItems);
        const countLabel = form.querySelector('[data-prescription-item-count]');

        countLabel.textContent = `${itemCount} dari ${maximumItems} jenis obat`;
        addButton.disabled = itemCount >= maximumItems;
    };

    document.addEventListener('click', (event) => {
        const addButton = event.target.closest('[data-add-prescription-item]');

        if (addButton) {
            const form = addButton.closest('form');
            const list = form.querySelector('[data-prescription-items]');
            const template = form.querySelector('[data-prescription-item-template]');
            const itemCount = list.querySelectorAll('.prescription-item-row').length;
            const maximumItems = Number(form.dataset.maxPrescriptionItems);

            if (itemCount >= maximumItems) {
                return;
            }

            const existingIndexes = [...list.querySelectorAll('[name^="items["]')]
                .map((input) => Number(input.name.match(/^items\[(\d+)\]/)?.[1] ?? -1));
            const index = Math.max(Number(form.dataset.nextPrescriptionItemIndex ?? 0), ...existingIndexes) + 1;
            const item = template.content.cloneNode(true);

            item.querySelectorAll('[name]').forEach((input) => {
                input.name = input.name.replaceAll('__INDEX__', index);
            });
            form.dataset.nextPrescriptionItemIndex = index;
            list.append(item);
            updatePrescriptionItemCount(form);
        }

        const removeButton = event.target.closest('[data-remove-prescription-item]');

        if (removeButton) {
            const form = removeButton.closest('form');
            removeButton.closest('.prescription-item-row').remove();
            updatePrescriptionItemCount(form);
        }
    });

    const refreshWorkflow = async () => {
        const currentWorkflow = document.querySelector('#clinic-workflow');

        if (!currentWorkflow || document.hidden || currentWorkflow.contains(document.activeElement)) {
            return;
        }

        try {
            const response = await fetch(currentWorkflow.dataset.pollUrl, {
                headers: {
                    Accept: 'text/html',
                    'X-Requested-With': 'XMLHttpRequest',
                },
                cache: 'no-store',
            });

            if (!response.ok) {
                return;
            }

            const markup = await response.text();
            const documentFragment = new DOMParser().parseFromString(markup, 'text/html');
            const updatedWorkflow = documentFragment.querySelector('#clinic-workflow');

            if (!updatedWorkflow) {
                return;
            }

            ['total', 'menunggu_verifikasi', 'menunggu_dokter', 'konsultasi', 'resep_total', 'resep_menunggu', 'resep_diproses'].forEach((key) => {
                const counter = document.querySelector(`[data-count="${key}"]`);
                const dataKey = key.replace(/(^|_)([a-z])/g, (_, __, letter) => letter.toUpperCase());
                const value = updatedWorkflow.dataset[`count${dataKey}`];

                if (counter && value !== undefined) {
                    counter.textContent = value;
                }
            });

            currentWorkflow.replaceWith(updatedWorkflow);
        } catch {
            // Kegagalan polling tidak mengganggu penggunaan formulir; halaman tetap dapat dimuat ulang manual.
        }
    };

    window.setInterval(refreshWorkflow, 15000);
})();
