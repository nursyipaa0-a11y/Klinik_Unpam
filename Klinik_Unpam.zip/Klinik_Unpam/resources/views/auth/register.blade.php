<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#edf3fc">
        <title>Daftar | Klinik UNPAM</title>
        <link rel="stylesheet" href="{{ asset('css/auth.css') }}">
    </head>
    <body class="auth-page">
        <a class="skip-link" href="#auth-form">Lewati ke formulir pendaftaran</a>
        <main class="auth-shell auth-shell-register">
            <aside class="auth-aside" aria-label="Informasi pendaftaran Klinik UNPAM">
                <a class="brand" href="{{ route('landing') }}" aria-label="Klinik UNPAM, halaman utama">
                    <span class="brand-mark" aria-hidden="true">+</span>
                    <span><strong>Klinik UNPAM</strong><small>Layanan kesehatan keluarga</small></span>
                </a>

                <div class="aside-copy">
                    <span class="eyebrow"><span class="online-dot" aria-hidden="true"></span> Mulai dari sini</span>
                    <h1>Akun yang tepat, layanan yang lebih mudah.</h1>
                    <p>Buat akun untuk mengakses layanan Klinik UNPAM sesuai kebutuhan Anda.</p>
                </div>

                <ul class="benefit-list">
                    <li><span aria-hidden="true">✓</span> Pendaftaran mudah dan jelas</li>
                    <li><span aria-hidden="true">✓</span> Informasi akun tersimpan aman</li>
                    <li><span aria-hidden="true">✓</span> Akses disesuaikan dengan peran</li>
                </ul>

                <p class="aside-footer">Pendaftaran tenaga klinik memerlukan verifikasi.</p>
            </aside>

            <section class="auth-content" aria-labelledby="form-title">
                <div class="mobile-brand">
                    <span class="brand-mark" aria-hidden="true">+</span>
                    <strong>Klinik UNPAM</strong>
                </div>

                <div class="form-heading">
                    <span class="form-step">BUAT AKUN BARU</span>
                    <h2 id="form-title">Daftar akun</h2>
                    <p>Lengkapi data akun Anda.</p>
                </div>

                @if ($errors->any())
                    <div class="alert alert-error" role="alert" tabindex="-1">
                        <strong>Periksa kembali data Anda.</strong>
                        <span>{{ $errors->first() }}</span>
                    </div>
                @endif

                <form id="auth-form" class="auth-form register-form" method="POST" action="{{ route('register') }}">
                    @csrf

                    <div class="field-grid">
                        <div class="field">
                            <label for="name">Nama lengkap <span aria-hidden="true">*</span></label>
                            <input type="text" name="name" id="name" value="{{ old('name') }}" placeholder="Nama sesuai identitas" autocomplete="name" required aria-invalid="{{ $errors->has('name') ? 'true' : 'false' }}" aria-describedby="name-error">
                            @error('name') <span class="field-error" id="name-error">{{ $message }}</span> @enderror
                        </div>

                        <div class="field">
                            <label for="role">Daftar sebagai <span aria-hidden="true">*</span></label>
                            <select name="role" id="role" required>
                                <option value="pasien" {{ old('role', 'pasien') === 'pasien' ? 'selected' : '' }}>Pasien</option>
                                <option value="dokter" {{ old('role') === 'dokter' ? 'selected' : '' }}>Dokter</option>
                                <option value="apoteker" {{ old('role') === 'apoteker' ? 'selected' : '' }}>Apoteker</option>
                                <option value="suster" {{ old('role') === 'suster' ? 'selected' : '' }}>Perawat</option>
                            </select>
                        </div>
                    </div>

                    <div class="field-grid">
                        <div class="field">
                            <label for="email">Alamat email <span aria-hidden="true">*</span></label>
                            <input type="email" name="email" id="email" value="{{ old('email') }}" placeholder="nama@email.com" autocomplete="email" inputmode="email" required aria-invalid="{{ $errors->has('email') ? 'true' : 'false' }}" aria-describedby="email-error">
                            @error('email') <span class="field-error" id="email-error">{{ $message }}</span> @enderror
                        </div>

                        <div class="field">
                            <label for="phone">Nomor telepon</label>
                            <input type="tel" name="phone" id="phone" value="{{ old('phone') }}" placeholder="08xxxxxxxxxx" autocomplete="tel" inputmode="tel" aria-invalid="{{ $errors->has('phone') ? 'true' : 'false' }}" aria-describedby="phone-error">
                            @error('phone') <span class="field-error" id="phone-error">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="patient-fields" data-patient-fields {{ old('role', 'pasien') === 'pasien' ? '' : 'hidden' }}>
                        <div class="field-grid">
                            <div class="field">
                                <label for="national_id">NIK <span aria-hidden="true">*</span></label>
                                <input type="text" name="national_id" id="national_id" value="{{ old('national_id') }}" placeholder="16 digit NIK" inputmode="numeric" maxlength="16" autocomplete="off" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('national_id') ? 'true' : 'false' }}" aria-describedby="national-id-error">
                                @error('national_id') <span class="field-error" id="national-id-error">{{ $message }}</span> @enderror
                            </div>
                            <div class="field">
                                <label for="date_of_birth">Tanggal lahir <span aria-hidden="true">*</span></label>
                                <input type="date" name="date_of_birth" id="date_of_birth" value="{{ old('date_of_birth') }}" max="{{ now()->subDay()->toDateString() }}" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('date_of_birth') ? 'true' : 'false' }}" aria-describedby="date-of-birth-error">
                                @error('date_of_birth') <span class="field-error" id="date-of-birth-error">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div class="field-grid">
                            <div class="field">
                                <label for="gender">Jenis kelamin <span aria-hidden="true">*</span></label>
                                <select name="gender" id="gender" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('gender') ? 'true' : 'false' }}" aria-describedby="gender-error">
                                    <option value="">Pilih jenis kelamin</option>
                                    <option value="Laki-laki" {{ old('gender') === 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                                    <option value="Perempuan" {{ old('gender') === 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                                </select>
                                @error('gender') <span class="field-error" id="gender-error">{{ $message }}</span> @enderror
                            </div>
                            <div class="field">
                                <label for="blood_type">Golongan darah</label>
                                <select name="blood_type" id="blood_type">
                                    <option value="">Belum diketahui</option>
                                    @foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bloodType)
                                        <option value="{{ $bloodType }}" {{ old('blood_type') === $bloodType ? 'selected' : '' }}>{{ $bloodType }}</option>
                                    @endforeach
                                </select>
                                @error('blood_type') <span class="field-error">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div class="field">
                            <label for="address">Alamat lengkap <span aria-hidden="true">*</span></label>
                            <textarea name="address" id="address" rows="3" maxlength="2000" autocomplete="street-address" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('address') ? 'true' : 'false' }}" aria-describedby="address-error">{{ old('address') }}</textarea>
                            @error('address') <span class="field-error" id="address-error">{{ $message }}</span> @enderror
                        </div>
                        <div class="field-grid">
                            <div class="field">
                                <label for="emergency_contact_name">Nama kontak darurat <span aria-hidden="true">*</span></label>
                                <input type="text" name="emergency_contact_name" id="emergency_contact_name" value="{{ old('emergency_contact_name') }}" autocomplete="off" maxlength="255" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('emergency_contact_name') ? 'true' : 'false' }}" aria-describedby="emergency-contact-name-error">
                                @error('emergency_contact_name') <span class="field-error" id="emergency-contact-name-error">{{ $message }}</span> @enderror
                            </div>
                            <div class="field">
                                <label for="emergency_contact_phone">Telepon kontak darurat <span aria-hidden="true">*</span></label>
                                <input type="tel" name="emergency_contact_phone" id="emergency_contact_phone" value="{{ old('emergency_contact_phone') }}" autocomplete="off" inputmode="tel" maxlength="20" {{ old('role', 'pasien') === 'pasien' ? 'required' : '' }} aria-invalid="{{ $errors->has('emergency_contact_phone') ? 'true' : 'false' }}" aria-describedby="emergency-contact-phone-error">
                                @error('emergency_contact_phone') <span class="field-error" id="emergency-contact-phone-error">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div class="field">
                            <label for="medical_history">Riwayat penyakit</label>
                            <textarea name="medical_history" id="medical_history" rows="3" maxlength="4000" placeholder="Isi riwayat penyakit, alergi, atau obat rutin jika ada">{{ old('medical_history') }}</textarea>
                            @error('medical_history') <span class="field-error">{{ $message }}</span> @enderror
                        </div>
                    </div>

                    <div class="staff-fields" data-staff-fields {{ old('role', 'pasien') === 'pasien' ? 'hidden' : '' }}>
                        <div class="field-grid">
                            <div class="field">
                                <label for="staff_number">Nomor identitas staf <span aria-hidden="true">*</span></label>
                                <input type="text" name="staff_number" id="staff_number" value="{{ old('staff_number') }}" placeholder="Nomor dari administrasi klinik" autocomplete="off" maxlength="50" {{ old('role', 'pasien') === 'pasien' ? '' : 'required' }} aria-invalid="{{ $errors->has('staff_number') ? 'true' : 'false' }}" aria-describedby="staff-number-help staff-number-error">
                                <small id="staff-number-help">Nomor ini harus unik dan diberikan oleh klinik.</small>
                                @error('staff_number') <span class="field-error" id="staff-number-error">{{ $message }}</span> @enderror
                            </div>

                            <div class="field">
                                <label for="registration_code">Kode pendaftaran staf <span aria-hidden="true">*</span></label>
                                <input type="password" name="registration_code" id="registration_code" placeholder="Kode resmi dari administrasi" autocomplete="off" maxlength="100" {{ old('role', 'pasien') === 'pasien' ? '' : 'required' }} aria-invalid="{{ $errors->has('registration_code') ? 'true' : 'false' }}" aria-describedby="registration-code-help registration-code-error">
                                <small id="registration-code-help">Minta kode khusus role Anda kepada administrasi klinik.</small>
                                @error('registration_code') <span class="field-error" id="registration-code-error">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>

                    <div class="field-grid">
                        <div class="field">
                            <label for="password">Kata sandi <span aria-hidden="true">*</span></label>
                            <input type="password" name="password" id="password" placeholder="Minimal 8 karakter" autocomplete="new-password" minlength="8" required aria-invalid="{{ $errors->has('password') ? 'true' : 'false' }}" aria-describedby="password-error">
                            @error('password') <span class="field-error" id="password-error">{{ $message }}</span> @enderror
                        </div>

                        <div class="field">
                            <label for="password_confirmation">Ulangi kata sandi <span aria-hidden="true">*</span></label>
                            <input type="password" name="password_confirmation" id="password_confirmation" placeholder="Ketik ulang kata sandi" autocomplete="new-password" minlength="8" required>
                        </div>
                    </div>

                    <button class="submit-button" type="submit">Buat akun <span aria-hidden="true">→</span></button>
                </form>

                <p class="form-switch">Sudah punya akun? <a href="{{ route('login') }}">Masuk di sini</a></p>
                <a class="home-link" href="{{ route('landing') }}">← Kembali ke halaman utama</a>
            </section>
        </main>

        <script>
            const roleSelect = document.querySelector('#role');
            const staffFields = document.querySelector('[data-staff-fields]');
            const patientFields = document.querySelector('[data-patient-fields]');

            const updateStaffFields = () => {
                const isStaff = roleSelect.value !== 'pasien';

                staffFields.hidden = !isStaff;
                staffFields.querySelectorAll('input').forEach((input) => {
                    input.required = isStaff;
                });

                patientFields.hidden = isStaff;
                patientFields.querySelectorAll('#national_id, #date_of_birth, #gender, #address, #emergency_contact_name, #emergency_contact_phone').forEach((field) => {
                    field.required = !isStaff;
                });
            };

            roleSelect.addEventListener('change', updateStaffFields);
            updateStaffFields();
        </script>
    </body>
</html>
