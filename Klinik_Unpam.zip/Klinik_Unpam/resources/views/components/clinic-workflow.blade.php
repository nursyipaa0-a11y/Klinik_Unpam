<section id="clinic-workflow" class="workflow-section" aria-live="polite" data-poll-url="{{ route('dashboard.workflow') }}" data-count-total="{{ $visitCounts['total'] }}" data-count-menunggu-verifikasi="{{ $visitCounts['menunggu_verifikasi'] }}" data-count-menunggu-dokter="{{ $visitCounts['menunggu_dokter'] }}" data-count-konsultasi="{{ $visitCounts['konsultasi'] }}" data-count-resep-total="{{ $prescriptionCounts['total'] }}" data-count-resep-menunggu="{{ $prescriptionCounts['menunggu'] }}" data-count-resep-diproses="{{ $prescriptionCounts['diproses'] }}">
    @if ($errors->any())
        <div class="notice notice-error" role="alert">{{ $errors->first() }}</div>
    @endif
    @if (session('success'))
        <div class="notice notice-success" role="status">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="notice notice-error" role="alert">{{ session('error') }}</div>
    @endif

    @if ($user->role === 'pasien')
        <section class="panel booking-panel" aria-labelledby="booking-title">
            <div class="panel-heading">
                <div><p class="eyebrow">LAYANAN PASIEN</p><h2 id="booking-title">Ambil nomor antrean</h2></div>
                <span class="panel-icon" aria-hidden="true">01</span>
            </div>
            <p class="panel-copy">Pilih poli. Permintaan Anda langsung tersimpan dan diterima oleh perawat.</p>
            <form class="clinic-form booking-form" method="POST" action="{{ route('visits.store') }}">
                @csrf
                <div class="form-field">
                    <label for="service">Pilih poli</label>
                    <select id="service" name="service" required>
                        <option value="">Pilih poli</option>
                        <option value="Poli Umum">Poli Umum</option>
                        <option value="Poli Gigi">Poli Gigi</option>
                        <option value="Poli KIA">Poli Kesehatan Ibu dan Anak</option>
                        <option value="Poli Ortopedi">Poli Ortopedi</option>
                    </select>
                    @error('service') <span class="field-error">{{ $message }}</span> @enderror
                </div>
                <div class="form-field form-field-wide">
                    <label for="complaint">Keluhan/catatan untuk perawat</label>
                    <textarea id="complaint" name="complaint" rows="3" maxlength="2000" placeholder="Tuliskan informasi yang perlu diketahui perawat">{{ old('complaint') }}</textarea>
                    @error('complaint') <span class="field-error">{{ $message }}</span> @enderror
                </div>
                <button class="button button-primary" type="submit">Minta nomor antrean</button>
            </form>
        </section>

        <section class="panel patient-queue-panel" aria-labelledby="patient-queue-title">
            <div class="panel-heading">
                <div><p class="eyebrow">ANTREAN ANDA</p><h2 id="patient-queue-title">Nomor dan perkiraan panggilan</h2></div>
                <span class="panel-count">{{ $visits->count() }} antrean aktif</span>
            </div>
            @if ($visits->isEmpty())
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">01</span><div><strong>Belum ada antrean aktif</strong><p>Setelah memilih poli, nomor antrean dan perkiraan panggilan akan tampil di sini.</p></div></div>
            @else
                <div class="patient-queue-list">
                    @foreach ($visits as $visit)
                        @php
                            $patientQueueStatus = match ($visit->status) {
                                'menunggu_verifikasi', 'menunggu_dokter' => 'Menunggu dipanggil dokter',
                                'dipanggil' => 'Dokter sedang memanggil Anda',
                                'konsultasi' => 'Sedang diperiksa dokter',
                                default => $visit->status,
                            };
                        @endphp
                        <article class="patient-queue-card">
                            <div class="patient-queue-heading">
                                <div>
                                    <span class="queue-number">{{ $visit->service }}</span>
                                    <h3>{{ $visit->queue_number }}</h3>
                                    <p class="visit-meta">Nomor antrean poli Anda · {{ $visit->created_at->format('d M Y, H:i') }}</p>
                                </div>
                                <span class="status-pill">{{ $patientQueueStatus }}</span>
                            </div>
                            @if ($visit->status === 'menunggu_verifikasi' || $visit->status === 'menunggu_dokter')
                                <p class="call-estimate"><strong>Perkiraan panggilan:</strong> {{ $queueCallEstimates[$visit->id] ?? 'Sedang menghitung antrean.' }}</p>
                            @elseif ($visit->status === 'dipanggil')
                                <p class="call-estimate call-estimate-active"><strong>Silakan menuju ruang pemeriksaan.</strong> {{ $queueCallEstimates[$visit->id] ?? '' }}</p>
                            @elseif ($visit->status === 'konsultasi')
                                <p class="call-estimate"><strong>Status:</strong> {{ $queueCallEstimates[$visit->id] ?? 'Sedang diperiksa dokter.' }}</p>
                            @endif
                            @if ($visit->doctor && $visit->status !== 'menunggu_dokter')
                                <p class="visit-meta">Dokter: {{ $visit->doctor->name }}</p>
                            @endif
                            @if ($visit->prescription)
                                @if ($visit->prescription->status === 'stok_tidak_cukup')
                                    <div class="patient-pharmacy-note"><strong>Apotek sedang memastikan ketersediaan obat.</strong><span>Rincian obat ditangani tenaga klinik.</span></div>
                                @elseif (in_array($visit->prescription->status, ['menunggu', 'diproses'], true))
                                    <div class="patient-pharmacy-note"><strong>Permintaan obat diterima apotek.</strong><span>Apotek sedang menyiapkan obat Anda.</span></div>
                                @elseif ($visit->prescription->status === 'siap_diambil')
                                    <div class="patient-pharmacy-note"><strong>Obat siap diambil di apotek.</strong><span>Silakan ke loket apotek untuk mengambil obat dan melakukan pembayaran.</span></div>
                                    @if ($visit->payment)
                                        <div class="patient-payment"><span>Total pembayaran</span><strong>Rp {{ number_format((float) $visit->payment->amount, 0, ',', '.') }}</strong><span>Status: {{ $visit->payment->status === 'dibayar' ? 'Sudah dibayar' : 'Belum dibayar' }}</span></div>
                                    @endif
                                @elseif ($visit->prescription->status === 'diserahkan')
                                    <div class="patient-pharmacy-note"><strong>Pengambilan obat selesai.</strong><span>Pembayaran: {{ $visit->payment?->status === 'dibayar' ? 'Lunas' : 'Belum tercatat' }}.</span></div>
                                @endif
                            @endif
                            @if (in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true))
                                <form method="POST" action="{{ route('visits.status', $visit) }}">
                                    @csrf @method('PATCH')
                                    <input type="hidden" name="status" value="dibatalkan">
                                    <button class="button button-outline" type="submit">Batalkan antrean</button>
                                </form>
                            @endif
                        </article>
                    @endforeach
                </div>
            @endif
        </section>
    @endif

    @if ($user->role !== 'pasien')
    <section class="panel" aria-labelledby="visits-title">
        <div class="panel-heading">
            <div><p class="eyebrow">ALUR PELAYANAN</p><h2 id="visits-title">Antrean dan data pasien</h2></div>
            <span class="panel-count">{{ $visits->count() }} kunjungan</span>
        </div>

        @if ($visits->isEmpty())
            <div class="empty-state"><span class="empty-icon" aria-hidden="true">01</span><div><strong>Belum ada antrean</strong><p>Data permintaan pasien akan muncul di sini setelah disimpan.</p></div></div>
        @else
            <div class="visit-list">
                @foreach ($visits as $visit)
                    @php
                        $visitStatusLabel = match ($visit->status) {
                            'menunggu_verifikasi', 'menunggu_dokter' => 'Menunggu dipanggil dokter',
                            'dipanggil' => 'Dokter memanggil pasien',
                            'konsultasi' => 'Sedang diperiksa dokter',
                            'selesai' => 'Pemeriksaan selesai',
                            'dibatalkan' => 'Permintaan dibatalkan',
                            default => $visit->status,
                        };
                    @endphp
                    <article class="visit-card">
                        <div class="visit-card-top">
                            <div>
                                <p class="queue-number">Nomor antrean poli: {{ $visit->queue_number }}</p>
                                <h3>{{ $visit->service }}</h3>
                                <p class="visit-meta">Pasien: {{ $visit->patient->name }} · Dibuat {{ $visit->created_at->format('d M Y, H:i') }}</p>
                            </div>
                            <span class="status-pill">{{ $visitStatusLabel }}</span>
                        </div>

                        @if ($visit->complaint && in_array($user->role, ['pasien', 'dokter', 'suster'], true))
                            <p class="visit-note"><strong>Catatan pasien:</strong> {{ $visit->complaint }}</p>
                        @endif
                        @if ($user->role === 'suster')
                            <div class="patient-details" aria-label="Data pasien">
                                <p class="visit-meta"><strong>Data pasien</strong></p>
                                <dl class="patient-details-list">
                                    <div><dt>NIK</dt><dd>{{ $visit->patient->national_id ?: 'Belum diisi' }}</dd></div>
                                    <div><dt>Tanggal lahir</dt><dd>{{ $visit->patient->date_of_birth?->format('d M Y') ?? 'Belum diisi' }}</dd></div>
                                    <div><dt>Jenis kelamin</dt><dd>{{ $visit->patient->gender ?: 'Belum diisi' }}</dd></div>
                                    <div><dt>Telepon</dt><dd>{{ $visit->patient->phone ?: 'Belum diisi' }}</dd></div>
                                    <div><dt>Alamat</dt><dd>{{ $visit->patient->address ?: 'Belum diisi' }}</dd></div>
                                    <div><dt>Kontak darurat</dt><dd>{{ $visit->patient->emergency_contact_name ?: 'Belum diisi' }} · {{ $visit->patient->emergency_contact_phone ?: 'Belum diisi' }}</dd></div>
                                    <div><dt>Golongan darah</dt><dd>{{ $visit->patient->blood_type ?: 'Belum diketahui' }}</dd></div>
                                    <div class="patient-details-wide"><dt>Riwayat penyakit</dt><dd>{{ $visit->patient->medical_history ?: 'Belum diisi pasien' }}</dd></div>
                                </dl>
                            </div>
                        @endif
                        @if ($visit->doctor && in_array($user->role, ['pasien', 'dokter', 'suster'], true))
                            <p class="visit-meta">Dokter: {{ $visit->doctor->name }}</p>
                        @endif

                        @if ($user->role === 'pasien' && $visit->prescription)
                            @if ($visit->prescription->status === 'stok_tidak_cukup')
                                <div class="patient-pharmacy-note"><strong>Apotek sedang memastikan ketersediaan obat.</strong><span>Silakan pantau pembaruan. Rincian obat ditangani tenaga klinik.</span></div>
                            @elseif (in_array($visit->prescription->status, ['menunggu', 'diproses'], true))
                                <div class="patient-pharmacy-note"><strong>Permintaan obat sudah diterima apotek.</strong><span>Apotek sedang menyiapkan obat Anda.</span></div>
                            @elseif ($visit->prescription->status === 'siap_diambil')
                                <div class="patient-pharmacy-note"><strong>Obat siap diambil di apotek.</strong><span>Silakan ke loket apotek untuk mengambil obat dan melakukan pembayaran.</span></div>
                                @if ($visit->payment)
                                    <div class="patient-payment"><span>Total pembayaran</span><strong>Rp {{ number_format((float) $visit->payment->amount, 0, ',', '.') }}</strong><span>Status: {{ $visit->payment->status === 'dibayar' ? 'Sudah dibayar' : 'Belum dibayar' }}</span></div>
                                @endif
                            @elseif ($visit->prescription->status === 'diserahkan')
                                <div class="patient-pharmacy-note"><strong>Pengambilan obat selesai.</strong><span>Pembayaran: {{ $visit->payment?->status === 'dibayar' ? 'Lunas' : 'Belum tercatat' }}.</span></div>
                            @endif
                        @endif

                        <div class="visit-actions">
                            @if ($user->role === 'pasien' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true))
                                <form method="POST" action="{{ route('visits.status', $visit) }}">
                                    @csrf @method('PATCH')
                                    <input type="hidden" name="status" value="dibatalkan">
                                    <button class="button button-outline" type="submit">Batalkan antrean</button>
                                </form>
                            @elseif ($user->role === 'dokter' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true))
                                <form method="POST" action="{{ route('visits.status', $visit) }}">
                                    @csrf @method('PATCH')
                                    <input type="hidden" name="status" value="dipanggil">
                                    <button class="button button-primary" type="submit">Panggil pasien</button>
                                </form>
                            @elseif ($user->role === 'dokter' && $visit->status === 'dipanggil' && $visit->assigned_doctor_id === $user->id)
                                <form method="POST" action="{{ route('visits.status', $visit) }}">
                                    @csrf @method('PATCH')
                                    <input type="hidden" name="status" value="konsultasi">
                                    <button class="button button-primary" type="submit">Mulai pemeriksaan</button>
                                </form>
                            @elseif ($user->role === 'dokter' && $visit->status === 'konsultasi' && $visit->assigned_doctor_id === $user->id)
                                @if (! $visit->prescription)
                                    <details class="action-details">
                                        <summary class="button button-outline">Tulis resep</summary>
                                        <form class="clinic-form prescription-form" method="POST" action="{{ route('visits.prescriptions.store', $visit) }}" data-max-prescription-items="10">
                                            @csrf
                                            <div class="prescription-item-list" data-prescription-items>
                                                <div class="prescription-item-row">
                                                    <div class="form-field">
                                                        <label>Obat</label>
                                                        <select name="items[0][medicine_id]" required>
                                                            <option value="">Pilih obat</option>
                                                            @foreach ($medicines as $medicine)
                                                                <option value="{{ $medicine->id }}">{{ $medicine->name }} — {{ $medicine->form }}, {{ $medicine->strength }} (stok {{ $medicine->stock }})</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="form-field">
                                                        <label>Jumlah obat</label>
                                                        <input type="number" name="items[0][quantity]" min="1" max="100" value="1" required>
                                                    </div>
                                                    <div class="form-field form-field-wide">
                                                        <label>Aturan pakai dari dokter</label>
                                                        <input type="text" name="items[0][dosage]" maxlength="255" placeholder="Tulis aturan pakai pasien" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="visit-meta" data-prescription-item-count aria-live="polite">1 dari 10 jenis obat</p>
                                            <button class="button button-outline" type="button" data-add-prescription-item>Tambah obat</button>
                                            <template data-prescription-item-template>
                                                <div class="prescription-item-row">
                                                    <div class="form-field">
                                                        <label>Obat</label>
                                                        <select name="items[__INDEX__][medicine_id]" required>
                                                            <option value="">Pilih obat</option>
                                                            @foreach ($medicines as $medicine)
                                                                <option value="{{ $medicine->id }}">{{ $medicine->name }} — {{ $medicine->form }}, {{ $medicine->strength }} (stok {{ $medicine->stock }})</option>
                                                            @endforeach
                                                        </select>
                                                    </div>
                                                    <div class="form-field">
                                                        <label>Jumlah obat</label>
                                                        <input type="number" name="items[__INDEX__][quantity]" min="1" max="100" value="1" required>
                                                    </div>
                                                    <div class="form-field form-field-wide">
                                                        <label>Aturan pakai dari dokter</label>
                                                        <input type="text" name="items[__INDEX__][dosage]" maxlength="255" placeholder="Tulis aturan pakai pasien" required>
                                                    </div>
                                                    <button class="button button-outline" type="button" data-remove-prescription-item>Hapus obat ini</button>
                                                </div>
                                            </template>
                                            <button class="button button-primary" type="submit">Kirim resep ke apotek</button>
                                        </form>
                                    </details>
                                @else
                                    <p class="visit-meta">Resep sudah dikirim ke apotek untuk diproses.</p>
                                @endif
                                <form method="POST" action="{{ route('visits.status', $visit) }}">
                                    @csrf @method('PATCH')
                                    <input type="hidden" name="status" value="selesai">
                                    <button class="button button-primary" type="submit" {{ $visit->prescription ? '' : 'disabled' }}>Selesaikan pemeriksaan</button>
                                </form>
                            @endif
                        </div>
                    </article>
                @endforeach
            </div>
        @endif
    </section>
    @endif

    @if ($user->role === 'pasien')
        <section class="panel history-panel" aria-labelledby="history-title">
            <div class="panel-heading">
                <div><p class="eyebrow">KUNJUNGAN ANDA</p><h2 id="history-title">Riwayat pasien</h2></div>
                <span class="panel-count">{{ $visitHistory->count() }} riwayat</span>
            </div>
            @if ($visitHistory->isEmpty())
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">03</span><div><strong>Riwayat masih kosong</strong><p>Kunjungan yang selesai atau dibatalkan akan tersimpan di sini.</p></div></div>
            @else
                <div class="history-scroll" role="region" aria-label="Daftar riwayat kunjungan pasien" tabindex="0">
                    <div class="visit-list">
                        @foreach ($visitHistory as $historyVisit)
                            <article class="visit-card history-card">
                                <div class="visit-card-top">
                                    <div>
                                        <p class="queue-number">Nomor antrean poli: {{ $historyVisit->queue_number }}</p>
                                        <h3>{{ $historyVisit->service }}</h3>
                                        <p class="visit-meta">{{ $historyVisit->created_at->format('d M Y, H:i') }}</p>
                                    </div>
                                    <span class="status-pill">{{ $historyVisit->status === 'selesai' ? 'Pemeriksaan selesai' : 'Dibatalkan' }}</span>
                                </div>
                                @if ($historyVisit->doctor)
                                    <p class="visit-meta">Dokter: {{ $historyVisit->doctor->name }}</p>
                                @endif
                                @if ($historyVisit->prescription)
                                    <p class="visit-meta">Status apotek: {{ match ($historyVisit->prescription->status) {
                                        'stok_tidak_cukup' => 'Apotek sedang memastikan ketersediaan obat',
                                        'menunggu' => 'Diterima apotek',
                                        'diproses' => 'Obat sedang disiapkan',
                                        'siap_diambil' => 'Siap diambil di apotek',
                                        'diserahkan' => 'Pengambilan selesai',
                                        default => 'Belum ada pembaruan',
                                    } }}</p>
                                @endif
                                @if ($historyVisit->payment)
                                    <p class="visit-meta">Pembayaran: {{ $historyVisit->payment->status === 'dibayar' ? 'Lunas' : 'Belum dibayar' }}</p>
                                @endif
                            </article>
                        @endforeach
                    </div>
                </div>
            @endif
        </section>
    @endif

    @if (in_array($user->role, ['dokter', 'apoteker'], true))
        <section id="prescriptions" class="panel" aria-labelledby="prescriptions-title">
            <div class="panel-heading">
                <div><p class="eyebrow">AKSES TENAGA KLINIK</p><h2 id="prescriptions-title">{{ $user->role === 'dokter' ? 'Resep yang saya tulis' : 'Resep masuk apotek' }}</h2></div>
                <span class="panel-count">{{ $prescriptions->count() }} resep</span>
            </div>
            @if ($prescriptions->isEmpty())
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">02</span><div><strong>Belum ada resep</strong><p>Resep tampil setelah dokter mengirimkannya dari pemeriksaan pasien.</p></div></div>
            @else
                <div class="prescription-list">
                    @foreach ($prescriptions as $prescription)
                        @php
                            $prescriptionStatusLabel = match ($prescription->status) {
                                'menunggu' => 'Baru masuk',
                                'stok_tidak_cukup' => 'Stok tidak cukup',
                                'diproses' => 'Sedang disiapkan',
                                'siap_diambil' => 'Siap diambil',
                                'diserahkan' => 'Sudah diserahkan',
                                default => $prescription->status,
                            };
                        @endphp
                        <article class="prescription-card">
                            <div class="visit-card-top">
                                <div>
                                    <p class="queue-number">Antrean {{ $prescription->visit->queue_number }}</p>
                                    <h3>{{ $prescription->visit->patient->name }} · {{ $prescription->visit->service }}</h3>
                                    <p class="visit-meta">Dokter: {{ $prescription->doctor->name }} · {{ $prescription->created_at->format('d M Y, H:i') }}</p>
                                </div>
                                <span class="status-pill">{{ $prescriptionStatusLabel }}</span>
                            </div>
                            <div class="prescription-drugs">
                                @foreach ($prescription->items as $item)
                                    <div class="prescription-drug">
                                        <strong>{{ $item->medicine->name }} — {{ $item->medicine->form }}, {{ $item->medicine->strength }}</strong>
                                        <span>Jumlah {{ $item->quantity }} {{ $item->medicine->unit }} · {{ $item->dosage }}</span>
                                        <small>Stok kini: {{ $item->medicine->stock }}</small>
                                    </div>
                                @endforeach
                            </div>
                            @if ($user->role === 'apoteker')
                                @if (in_array($prescription->status, ['menunggu', 'stok_tidak_cukup'], true))
                                    <form method="POST" action="{{ route('prescriptions.process', $prescription) }}">
                                        @csrf
                                        <button class="button button-primary" type="submit">Cek stok dan siapkan resep</button>
                                    </form>
                                @elseif ($prescription->status === 'diproses')
                                    <form method="POST" action="{{ route('prescriptions.status', $prescription) }}">
                                        @csrf @method('PATCH')
                                        <input type="hidden" name="status" value="siap_diambil">
                                        <button class="button button-primary" type="submit">Beri tahu siap diambil</button>
                                    </form>
                                @elseif ($prescription->status === 'siap_diambil' && $prescription->visit->payment?->status === 'belum_bayar')
                                    <div class="pharmacy-payment"><strong>Tagihan pasien: Rp {{ number_format((float) $prescription->visit->payment->amount, 0, ',', '.') }}</strong><span>Catat pembayaran setelah pasien membayar di loket.</span></div>
                                    <form method="POST" action="{{ route('payments.record', $prescription->visit->payment) }}">
                                        @csrf
                                        <button class="button button-primary" type="submit">Konfirmasi pembayaran tunai</button>
                                    </form>
                                @elseif ($prescription->status === 'siap_diambil' && $prescription->visit->payment?->status === 'dibayar')
                                    <div class="pharmacy-payment"><strong>Pembayaran diterima</strong><span>Rp {{ number_format((float) $prescription->visit->payment->amount, 0, ',', '.') }} · Tunai</span></div>
                                    <form method="POST" action="{{ route('prescriptions.status', $prescription) }}">
                                        @csrf @method('PATCH')
                                        <input type="hidden" name="status" value="diserahkan">
                                        <button class="button button-primary" type="submit">Serahkan obat ke pasien</button>
                                    </form>
                                @endif
                            @endif
                        </article>
                    @endforeach
                </div>
            @endif
        </section>
    @endif

    @if ($user->role === 'apoteker')
        <section class="panel" aria-labelledby="inventory-title">
            <div class="panel-heading">
                <div><p class="eyebrow">PERSEDIAAN</p><h2 id="inventory-title">Daftar stok obat</h2></div>
                <span class="panel-count">{{ $medicines->count() }} jenis obat</span>
            </div>
            <details class="medicine-create-details">
                <summary class="button button-primary">Tambah jenis obat</summary>
                <form class="clinic-form medicine-create-form" method="POST" action="{{ route('medicines.store') }}">
                    @csrf
                    <div class="form-field">
                        <label for="medicine-name">Nama obat</label>
                        <input id="medicine-name" type="text" name="name" maxlength="255" value="{{ old('name') }}" required>
                        @error('name') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-field">
                        <label for="medicine-form">Bentuk obat</label>
                        <input id="medicine-form" type="text" name="form" maxlength="60" placeholder="Tablet, kapsul, sirup" value="{{ old('form') }}" required>
                        @error('form') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-field">
                        <label for="medicine-strength">Dosis/kekuatan</label>
                        <input id="medicine-strength" type="text" name="strength" maxlength="100" placeholder="Contoh: 500 mg" value="{{ old('strength') }}" required>
                        @error('strength') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-field">
                        <label for="medicine-unit">Satuan stok</label>
                        <input id="medicine-unit" type="text" name="unit" maxlength="40" placeholder="tablet, kapsul, botol" value="{{ old('unit') }}" required>
                        @error('unit') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-field">
                        <label for="medicine-stock">Stok awal</label>
                        <input id="medicine-stock" type="number" name="stock" min="0" max="1000000" value="{{ old('stock', 0) }}" required>
                        @error('stock') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <div class="form-field">
                        <label for="medicine-price">Harga per satuan (Rp)</label>
                        <input id="medicine-price" type="number" name="unit_price" min="0.01" max="9999999999.99" step="0.01" value="{{ old('unit_price') }}" required>
                        @error('unit_price') <span class="field-error">{{ $message }}</span> @enderror
                    </div>
                    <button class="button button-primary" type="submit">Simpan obat</button>
                </form>
            </details>
            <div class="inventory-list">
                @foreach ($medicines as $medicine)
                    <article class="inventory-card">
                        <div>
                            <strong>{{ $medicine->name }}</strong>
                            <span>{{ $medicine->form }} · {{ $medicine->strength }} · Rp {{ number_format((float) $medicine->unit_price, 0, ',', '.') }}/{{ $medicine->unit }}</span>
                        </div>
                        <span class="stock-pill {{ $medicine->stock < 5 ? 'stock-low' : '' }}">Stok {{ $medicine->stock }} {{ $medicine->unit }}{{ $medicine->stock < 5 ? ' · Perlu restock' : '' }}</span>
                        <form class="restock-form" method="POST" action="{{ route('medicines.stock', $medicine) }}">
                            @csrf @method('PATCH')
                            <label class="visually-hidden" for="restock-{{ $medicine->id }}">Tambah stok {{ $medicine->name }}</label>
                            <input id="restock-{{ $medicine->id }}" type="number" name="quantity" min="1" max="1000" value="10" required>
                            <button class="button button-outline" type="submit">Tambah stok</button>
                        </form>
                    </article>
                @endforeach
            </div>
        </section>
    @endif
</section>
