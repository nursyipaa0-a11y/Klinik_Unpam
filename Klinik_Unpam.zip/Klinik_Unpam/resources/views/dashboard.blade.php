<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0b4fb3">
        <title>Dashboard {{ $roleLabel }} | Klinik UNPAM</title>
        <link rel="stylesheet" href="{{ asset('css/clinic-ui.css') }}">
    </head>
    <body class="clinic-ui">
        <div class="clinic-shell">
            <header class="clinic-header">
                <a class="clinic-brand" href="{{ route('dashboard') }}">
                    <span class="clinic-brand-mark" aria-hidden="true">+</span>
                    <span><strong>Klinik UNPAM</strong><small>Portal layanan klinik</small></span>
                </a>
                <nav class="clinic-nav" aria-label="Navigasi utama">
                    <a class="active" href="{{ route('dashboard') }}">Dashboard</a>
                    <a href="#clinic-workflow">Antrean &amp; kunjungan</a>
                    @if (in_array($user->role, ['dokter', 'apoteker'], true))
                        <a href="#prescriptions">Resep</a>
                    @endif
                </nav>
                <div class="clinic-account">
                    <div class="clinic-account-copy">
                        <strong>{{ $user->name }}</strong>
                        <span>{{ $roleLabel }}</span>
                    </div>
                    <a class="clinic-avatar" href="{{ route('profile') }}" aria-label="Akun {{ $user->name }}">{{ strtoupper(substr($user->name, 0, 2)) }}</a>
                </div>
            </header>

            <main class="clinic-main">
                <section class="welcome-panel">
                    <div>
                        <p class="eyebrow">DASHBOARD {{ strtoupper($roleLabel) }}</p>
                        <h1>Halo, {{ $user->name }}</h1>
                        <p class="welcome-copy">Pantau antrean dan pembaruan layanan klinik dari satu tempat.</p>
                    </div>
                    <div class="live-indicator"><span aria-hidden="true"></span> Data diperbarui otomatis</div>
                </section>

                <section class="summary-grid" aria-label="Ringkasan operasional">
                    <article class="summary-card"><span>Total kunjungan</span><strong data-count="total">{{ $visitCounts['total'] }}</strong><small>Data antrean tersimpan</small></article>
                    <article class="summary-card"><span>Menunggu dokter</span><strong data-count="menunggu_dokter">{{ $visitCounts['menunggu_dokter'] }}</strong><small>Data pasien tersimpan, siap dipanggil</small></article>
                    <article class="summary-card"><span>Dalam konsultasi</span><strong data-count="konsultasi">{{ $visitCounts['konsultasi'] }}</strong><small>Sedang ditangani dokter</small></article>
                    @if ($user->role === 'pasien')
                        <article class="summary-card"><span>Riwayat kunjungan</span><strong>{{ $visitCounts['riwayat'] }}</strong><small>Kunjungan selesai atau dibatalkan</small></article>
                    @endif
                    @if (in_array($user->role, ['dokter', 'apoteker'], true))
                        <article class="summary-card"><span>Total resep</span><strong data-count="resep_total">{{ $prescriptionCounts['total'] }}</strong><small>Resep tersimpan</small></article>
                        <article class="summary-card"><span>Resep menunggu</span><strong data-count="resep_menunggu">{{ $prescriptionCounts['menunggu'] }}</strong><small>Menunggu apoteker</small></article>
                        <article class="summary-card"><span>Resep diproses</span><strong data-count="resep_diproses">{{ $prescriptionCounts['diproses'] }}</strong><small>Sedang disiapkan</small></article>
                    @endif
                </section>

                @include('components.clinic-workflow')
            </main>

            <footer class="clinic-footer">
                <span>Klinik UNPAM · Informasi operasional akun {{ $roleLabel }}</span>
            </footer>
        </div>
        <script src="{{ asset('js/clinic-workflow.js') }}" defer></script>
    </body>
</html>
