<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Klinik UNPAM menyediakan layanan kesehatan 24 jam terpercaya untuk semua masyarakat.">
        <title>Klinik UNPAM | 24 Jam</title>
        <link rel="stylesheet" href="{{ asset('css/clinic.css') }}">
    </head>
    <body>
        <div class="page-shell">
            <header class="topbar-wrap">
                <div class="container topbar">
                    <div class="brand-wrap">
                        <div class="brand-logo">
                            <span>S</span>
                        </div>
                        <div class="brand-text">
                            <strong>Klinik</strong><span>UNPAM</span>
                        </div>
                    </div>

                    <nav class="main-nav" aria-label="Navigasi utama">
                        <a href="#services">Layanan</a>
                        <a href="#appointments">Jadwal</a>
                        <a href="#doctors">Dokter</a>
                        <a href="#articles">Artikel</a>
                        <a href="#contact">Kontak</a>
                    </nav>

                    <div class="nav-actions">
                        <a class="login-btn" href="{{ route('login') }}">Masuk / Daftar</a>
                    </div>
                </div>
            </header>

            <main>
                <section class="hero container">
                    <div class="hero-copy">
                        <div class="hero-kicker">Klinik UNPAM • 24 Jam</div>
                        <h1>Layanan Kesehatan 24 Jam Terpercaya untuk Mahasiswa &amp; Masyarakat</h1>
                        <p>
                            Layanan kesehatan modern yang siap membantu Anda kapan saja dengan tim medis profesional,
                            layanan darurat, pemeriksaan lengkap, dan sistem reservasi yang cepat, aman, dan mudah.
                        </p>

                        <div class="hero-buttons">
                            <a class="primary-btn" href="{{ route('login') }}">Reservasi Sekarang</a>
                            <a class="secondary-btn" href="#services">Lihat Layanan</a>
                        </div>
                    </div>

                    <aside class="appointment-panel" id="appointments">
                        <div class="panel-header">
                            <div>
                                <span class="small-label">Jadwal Anda Saat Ini</span>
                                <h3>A-012</h3>
                            </div>
                            <div class="status-dot"></div>
                        </div>

                        <div class="panel-time">
                            <span>Mohon menunggu</span>
                            <strong>08:30 - 09:15</strong>
                        </div>

                        <button type="button" class="panel-button">Lihat Jadwal Saya</button>

                        <div class="quick-actions">
                            <div class="quick-action">
                                <span class="icon">💬</span>
                                <span>Chat Dokter</span>
                            </div>
                            <div class="quick-action">
                                <span class="icon">🩺</span>
                                <span>Telekonsultasi</span>
                            </div>
                        </div>
                    </aside>
                </section>

                <section class="stats container" aria-label="Keunggulan layanan">
                    <article class="stat-card">
                        <div class="stat-icon blue">🚑</div>
                        <div>
                            <h4>Ambulans 24 Jam</h4>
                            <p>Ambulans siap siaga kapan saja</p>
                        </div>
                    </article>
                    <article class="stat-card">
                        <div class="stat-icon green">🏥</div>
                        <div>
                            <h4>Pelayanan Umum</h4>
                            <p>Pelayanan kesehatan untuk semua</p>
                        </div>
                    </article>
                    <article class="stat-card">
                        <div class="stat-icon orange">📅</div>
                        <div>
                            <h4>Jadwal Terintegrasi</h4>
                            <p>Jadwal klinik dan dokter terintegrasi</p>
                        </div>
                    </article>
                </section>

                <section class="services-section container" id="services">
                    <div class="section-header">
                        <span class="section-tag">Layanan Medis</span>
                        <h2>Pelayanan kesehatan yang lengkap dan terpercaya</h2>
                    </div>

                    <div class="service-grid">
                        <article class="service-card blue">
                            <div class="service-icon">🩺</div>
                            <h3>Poliklinik Umum</h3>
                            <p>Pemeriksaan umum, konsultasi, dan terapi dasar untuk semua usia.</p>
                        </article>
                        <article class="service-card teal">
                            <div class="service-icon">👶</div>
                            <h3>Ibu &amp; Anak</h3>
                            <p>Pelayanan kesehatan ibu, anak, dan konsultasi tumbuh kembang.</p>
                        </article>
                        <article class="service-card purple">
                            <div class="service-icon">🦴</div>
                            <h3>Ortopedi</h3>
                            <p>Diagnosis dan perawatan tulang, sendi, serta masalah muskuloskeletal.</p>
                        </article>
                        <article class="service-card orange">
                            <div class="service-icon">🦷</div>
                            <h3>Gigi</h3>
                            <p>Pemeriksaan gigi dan perawatan mulut untuk keluarga anda.</p>
                        </article>
                        <article class="service-card red">
                            <div class="service-icon">🧪</div>
                            <h3>Laboratorium</h3>
                            <p>Analisis kesehatan cepat dan akurat dengan fasilitas modern.</p>
                        </article>
                        <article class="service-card gold">
                            <div class="service-icon">📡</div>
                            <h3>Radiologi</h3>
                            <p>Pemeriksaan pencitraan medis untuk diagnosis yang lebih tepat.</p>
                        </article>
                    </div>
                </section>

                <section class="booking container" id="doctors">
                    <div class="booking-copy">
                        <span class="section-tag alt">Reservasi Online</span>
                        <h2>Proses reservasi yang cepat, mudah, dan aman</h2>
                    </div>

                    <div class="steps-grid">
                        <div class="step-card">
                            <span class="step-no">01</span>
                            <h3>Pilih Dokter</h3>
                            <p>Pilih dokter sesuai kebutuhan dan jadwal yang tersedia.</p>
                        </div>
                        <div class="step-card">
                            <span class="step-no">02</span>
                            <h3>Tentukan Tanggal</h3>
                            <p>Tentukan tanggal dan jam konsultasi sesuai kenyamanan Anda.</p>
                        </div>
                        <div class="step-card">
                            <span class="step-no">03</span>
                            <h3>Lengkapi Data</h3>
                            <p>Isi data dan verifikasi untuk konfirmasi jadwal yang lebih cepat.</p>
                        </div>
                    </div>
                </section>

                <section class="info-section container" id="articles">
                    <div class="info-photo">
                        <div class="photo-overlay">
                            <div class="mini-card">
                                <strong>24/7</strong>
                                <span>Ruang resepsionis</span>
                            </div>
                        </div>
                    </div>

                    <div class="info-copy">
                        <span class="section-tag alt">Sistem Terintegrasi</span>
                        <h2>Clinic Management System yang terintegrasi</h2>
                        <ul>
                            <li>Rekam medis elektronik dan data pasien yang aman</li>
                            <li>Manajemen antrean dan jadwal dokter lebih efisien</li>
                            <li>Dokumen administrasi, obat, dan pemeriksaan dalam satu sistem</li>
                            <li>Pelayanan yang lebih cepat, rapi, dan terukur setiap hari</li>
                        </ul>
                    </div>
                </section>

                <section class="bpjs-banner container" id="contact">
                    <div class="bpjs-content">
                        <div>
                            <span class="bpjs-label">Rujukan BPJS</span>
                            <h3>Cek status rujukan BPJS Anda sekarang</h3>
                        </div>
                        <a href="{{ route('login') }}" class="bpjs-btn">Cek Status</a>
                    </div>
                </section>
            </main>

            <footer class="site-footer">
                <div class="footer-top">
                    <div class="container footer-grid">
                        <div class="footer-brand">
                            <div class="brand-wrap">
                                <div class="brand-logo small">
                                    <span>S</span>
                                </div>
                                <div class="brand-text">
                                    <strong>Klinik</strong><span>UNPAM</span>
                                </div>
                            </div>
                            <p>Layanan kesehatan 24 jam untuk keluarga, mahasiswa, dan masyarakat umum.</p>
                        </div>

                        <div class="footer-col">
                            <h4>Tentang</h4>
                            <a href="#">Tentang kami</a>
                            <a href="#">Nilai kami</a>
                            <a href="#">Tim kami</a>
                        </div>

                        <div class="footer-col">
                            <h4>Layanan</h4>
                            <a href="#">Poliklinik</a>
                            <a href="#">Darurat</a>
                            <a href="#">Laboratorium</a>
                        </div>

                        <div class="footer-col">
                            <h4>Berita</h4>
                            <a href="#">Artikel kesehatan</a>
                            <a href="#">Perawatan kampus</a>
                            <a href="#">Update klinik</a>
                        </div>

                        <div class="footer-col">
                            <h4>Panduan</h4>
                            <a href="#">Cara reservasi</a>
                            <a href="#">FAQ</a>
                            <a href="#">Bantuan</a>
                        </div>
                    </div>
                </div>

                <div class="footer-bottom">
                    <div class="container footer-bottom-inner">
                        <p>© 2026 Klinik UNPAM. Hak cipta dilindungi.</p>
                        <div class="socials">
                            <span>f</span>
                            <span>◎</span>
                            <span>in</span>
                            <span>▶</span>
                        </div>
                    </div>
                </div>
            </footer>
        </div>
    </body>
</html>
