<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0b4fb3">
        <title>Data Saya | Klinik UNPAM</title>
        <link rel="stylesheet" href="{{ asset('css/clinic-ui.css') }}">
    </head>
    <body class="clinic-ui">
        <div class="clinic-shell">
            <header class="clinic-header profile-header">
                <h1 class="profile-header-title">Data pengguna</h1>
                <nav class="profile-navigation" aria-label="Navigasi akun">
                    <a class="button button-light" href="{{ route('dashboard') }}"><span aria-hidden="true">←</span> Kembali</a>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button class="button button-light" type="submit"><span aria-hidden="true">↪</span> Keluar</button>
                    </form>
                </nav>
            </header>

            <main class="profile-main">
                <section class="profile-intro">
                    <p>{{ $user->name }} · {{ $roleLabel }}</p>
                </section>

                @if ($errors->any())
                    <div class="notice notice-error" role="alert">{{ $errors->first() }}</div>
                @endif
                @if (session('success'))
                    <div class="notice notice-success" role="status">{{ session('success') }}</div>
                @endif

                <div class="profile-grid">
                    <section class="panel profile-card" aria-labelledby="account-info-title">
                        <div class="panel-heading">
                            <div><h2 id="account-info-title">Data akun</h2></div>
                        </div>
                        <dl class="profile-facts">
                            <div><dt>Peran</dt><dd>{{ $roleLabel }}</dd></div>
                            @if ($user->staff_number)
                                <div><dt>Nomor identitas staf</dt><dd>{{ $user->staff_number }}</dd></div>
                            @endif
                            <div><dt>Akun dibuat</dt><dd>{{ $user->created_at->format('d M Y') }}</dd></div>
                        </dl>

                        <form class="clinic-form" method="POST" action="{{ route('profile.update') }}">
                            @csrf
                            @method('PUT')
                            <div class="form-field form-field-wide">
                                <label for="name">Nama lengkap</label>
                                <input id="name" type="text" name="name" value="{{ old('name', $user->name) }}" maxlength="255" autocomplete="name" required aria-invalid="{{ $errors->has('name') ? 'true' : 'false' }}" aria-describedby="name-error">
                                @error('name') <span class="field-error">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-field form-field-wide">
                                <label for="email">Alamat email</label>
                                <input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" maxlength="255" autocomplete="email" required aria-invalid="{{ $errors->has('email') ? 'true' : 'false' }}" aria-describedby="email-error">
                                @error('email') <span class="field-error" id="email-error">{{ $message }}</span> @enderror
                            </div>
                            <div class="form-field form-field-wide">
                                <label for="phone">Nomor telepon</label>
                                <input id="phone" type="tel" name="phone" value="{{ old('phone', $user->phone) }}" maxlength="20" autocomplete="tel" inputmode="tel" placeholder="Tambahkan nomor telepon" aria-invalid="{{ $errors->has('phone') ? 'true' : 'false' }}" aria-describedby="phone-error">
                                @error('phone') <span class="field-error" id="phone-error">{{ $message }}</span> @enderror
                            </div>
                            @if ($user->role === 'pasien')
                                <div class="form-field form-field-wide">
                                    <label for="national_id">NIK</label>
                                    <input id="national_id" type="text" name="national_id" value="{{ old('national_id', $user->national_id) }}" inputmode="numeric" maxlength="16" autocomplete="off" required aria-invalid="{{ $errors->has('national_id') ? 'true' : 'false' }}" aria-describedby="national-id-error">
                                    @error('national_id') <span class="field-error" id="national-id-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field">
                                    <label for="date_of_birth">Tanggal lahir</label>
                                    <input id="date_of_birth" type="date" name="date_of_birth" value="{{ old('date_of_birth', $user->date_of_birth?->format('Y-m-d')) }}" max="{{ now()->subDay()->toDateString() }}" required aria-invalid="{{ $errors->has('date_of_birth') ? 'true' : 'false' }}" aria-describedby="date-of-birth-error">
                                    @error('date_of_birth') <span class="field-error" id="date-of-birth-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field">
                                    <label for="gender">Jenis kelamin</label>
                                    <select id="gender" name="gender" required aria-invalid="{{ $errors->has('gender') ? 'true' : 'false' }}" aria-describedby="gender-error">
                                        <option value="">Pilih jenis kelamin</option>
                                        <option value="Laki-laki" {{ old('gender', $user->gender) === 'Laki-laki' ? 'selected' : '' }}>Laki-laki</option>
                                        <option value="Perempuan" {{ old('gender', $user->gender) === 'Perempuan' ? 'selected' : '' }}>Perempuan</option>
                                    </select>
                                    @error('gender') <span class="field-error" id="gender-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field form-field-wide">
                                    <label for="address">Alamat lengkap</label>
                                    <textarea id="address" name="address" rows="3" maxlength="2000" autocomplete="street-address" required aria-invalid="{{ $errors->has('address') ? 'true' : 'false' }}" aria-describedby="address-error">{{ old('address', $user->address) }}</textarea>
                                    @error('address') <span class="field-error" id="address-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field">
                                    <label for="emergency_contact_name">Nama kontak darurat</label>
                                    <input id="emergency_contact_name" type="text" name="emergency_contact_name" value="{{ old('emergency_contact_name', $user->emergency_contact_name) }}" maxlength="255" autocomplete="off" required aria-invalid="{{ $errors->has('emergency_contact_name') ? 'true' : 'false' }}" aria-describedby="emergency-contact-name-error">
                                    @error('emergency_contact_name') <span class="field-error" id="emergency-contact-name-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field">
                                    <label for="emergency_contact_phone">Telepon kontak darurat</label>
                                    <input id="emergency_contact_phone" type="tel" name="emergency_contact_phone" value="{{ old('emergency_contact_phone', $user->emergency_contact_phone) }}" maxlength="20" autocomplete="off" inputmode="tel" required aria-invalid="{{ $errors->has('emergency_contact_phone') ? 'true' : 'false' }}" aria-describedby="emergency-contact-phone-error">
                                    @error('emergency_contact_phone') <span class="field-error" id="emergency-contact-phone-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field">
                                    <label for="blood_type">Golongan darah</label>
                                    <select id="blood_type" name="blood_type">
                                        <option value="">Belum diketahui</option>
                                        @foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $bloodType)
                                            <option value="{{ $bloodType }}" {{ old('blood_type', $user->blood_type) === $bloodType ? 'selected' : '' }}>{{ $bloodType }}</option>
                                        @endforeach
                                    </select>
                                    @error('blood_type') <span class="field-error">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-field form-field-wide">
                                    <label for="medical_history">Riwayat penyakit</label>
                                    <textarea id="medical_history" name="medical_history" rows="4" maxlength="4000" placeholder="Isi riwayat penyakit, alergi, atau obat rutin jika ada">{{ old('medical_history', $user->medical_history) }}</textarea>
                                    @error('medical_history') <span class="field-error" id="medical-history-error">{{ $message }}</span> @enderror
                                </div>
                            @endif
                            <button class="button button-primary" type="submit">Simpan perubahan</button>
                        </form>
                    </section>
                </div>
            </main>
            <footer class="clinic-footer profile-footer">
                <span>© 2026 Klinik UNPAM. Hak cipta dilindungi.</span>
            </footer>
        </div>
    </body>
</html>
