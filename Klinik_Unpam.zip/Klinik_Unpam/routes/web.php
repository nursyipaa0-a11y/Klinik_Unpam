<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\ClinicWorkflowController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('landing');
})->name('landing');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/login/password', [AuthController::class, 'updatePassword'])->name('login.password.update');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [ClinicWorkflowController::class, 'dashboard'])->name('dashboard');
    Route::get('/dashboard/workflow', [ClinicWorkflowController::class, 'workflow'])->name('dashboard.workflow');
    Route::post('/visits', [ClinicWorkflowController::class, 'storeVisit'])->name('visits.store');
    Route::patch('/visits/{visit}/status', [ClinicWorkflowController::class, 'updateVisitStatus'])->name('visits.status');
    Route::post('/visits/{visit}/prescriptions', [ClinicWorkflowController::class, 'storePrescription'])->name('visits.prescriptions.store');
    Route::patch('/prescriptions/{prescription}/status', [ClinicWorkflowController::class, 'updatePrescriptionStatus'])->name('prescriptions.status');
    Route::post('/prescriptions/{prescription}/process', [ClinicWorkflowController::class, 'processPrescription'])->name('prescriptions.process');
    Route::post('/payments/{payment}/record', [ClinicWorkflowController::class, 'recordPayment'])->name('payments.record');
    Route::post('/medicines', [ClinicWorkflowController::class, 'storeMedicine'])->name('medicines.store');
    Route::patch('/medicines/{medicine}/stock', [ClinicWorkflowController::class, 'restockMedicine'])->name('medicines.stock');
    Route::get('/profile', [ProfileController::class, 'show'])->name('profile');
    Route::put('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
});
