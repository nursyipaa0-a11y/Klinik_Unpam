<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0b4fb3">
        <title>Data Saya | Klinik UNPAM</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/clinic-ui.css')); ?>">
    </head>
    <body class="clinic-ui">
        <div class="clinic-shell">
            <header class="clinic-header profile-header">
                <h1 class="profile-header-title">Data pengguna</h1>
                <nav class="profile-navigation" aria-label="Navigasi akun">
                    <a class="button button-light" href="<?php echo e(route('dashboard')); ?>"><span aria-hidden="true">←</span> Kembali</a>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="button button-light" type="submit"><span aria-hidden="true">↪</span> Keluar</button>
                    </form>
                </nav>
            </header>

            <main class="profile-main">
                <section class="profile-intro">
                    <p><?php echo e($user->name); ?> · <?php echo e($roleLabel); ?></p>
                </section>

                <?php if($errors->any()): ?>
                    <div class="notice notice-error" role="alert"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="notice notice-success" role="status"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <div class="profile-grid">
                    <section class="panel profile-card" aria-labelledby="account-info-title">
                        <div class="panel-heading">
                            <div><h2 id="account-info-title">Data akun</h2></div>
                        </div>
                        <dl class="profile-facts">
                            <div><dt>Peran</dt><dd><?php echo e($roleLabel); ?></dd></div>
                            <?php if($user->staff_number): ?>
                                <div><dt>Nomor identitas staf</dt><dd><?php echo e($user->staff_number); ?></dd></div>
                            <?php endif; ?>
                            <div><dt>Akun dibuat</dt><dd><?php echo e($user->created_at->format('d M Y')); ?></dd></div>
                        </dl>

                        <form class="clinic-form" method="POST" action="<?php echo e(route('profile.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-field form-field-wide">
                                <label for="name">Nama lengkap</label>
                                <input id="name" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" maxlength="255" autocomplete="name" required aria-invalid="<?php echo e($errors->has('name') ? 'true' : 'false'); ?>" aria-describedby="name-error">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-field form-field-wide">
                                <label for="email">Alamat email</label>
                                <input id="email" type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" maxlength="255" autocomplete="email" required aria-invalid="<?php echo e($errors->has('email') ? 'true' : 'false'); ?>" aria-describedby="email-error">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="email-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-field form-field-wide">
                                <label for="phone">Nomor telepon</label>
                                <input id="phone" type="tel" name="phone" value="<?php echo e(old('phone', $user->phone)); ?>" maxlength="20" autocomplete="tel" inputmode="tel" placeholder="Tambahkan nomor telepon" aria-invalid="<?php echo e($errors->has('phone') ? 'true' : 'false'); ?>" aria-describedby="phone-error">
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="phone-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <?php if($user->role === 'pasien'): ?>
                                <div class="form-field form-field-wide">
                                    <label for="national_id">NIK</label>
                                    <input id="national_id" type="text" name="national_id" value="<?php echo e(old('national_id', $user->national_id)); ?>" inputmode="numeric" maxlength="16" autocomplete="off" required aria-invalid="<?php echo e($errors->has('national_id') ? 'true' : 'false'); ?>" aria-describedby="national-id-error">
                                    <?php $__errorArgs = ['national_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="national-id-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field">
                                    <label for="date_of_birth">Tanggal lahir</label>
                                    <input id="date_of_birth" type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth', $user->date_of_birth?->format('Y-m-d'))); ?>" max="<?php echo e(now()->subDay()->toDateString()); ?>" required aria-invalid="<?php echo e($errors->has('date_of_birth') ? 'true' : 'false'); ?>" aria-describedby="date-of-birth-error">
                                    <?php $__errorArgs = ['date_of_birth'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="date-of-birth-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field">
                                    <label for="gender">Jenis kelamin</label>
                                    <select id="gender" name="gender" required aria-invalid="<?php echo e($errors->has('gender') ? 'true' : 'false'); ?>" aria-describedby="gender-error">
                                        <option value="">Pilih jenis kelamin</option>
                                        <option value="Laki-laki" <?php echo e(old('gender', $user->gender) === 'Laki-laki' ? 'selected' : ''); ?>>Laki-laki</option>
                                        <option value="Perempuan" <?php echo e(old('gender', $user->gender) === 'Perempuan' ? 'selected' : ''); ?>>Perempuan</option>
                                    </select>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="gender-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field form-field-wide">
                                    <label for="address">Alamat lengkap</label>
                                    <textarea id="address" name="address" rows="3" maxlength="2000" autocomplete="street-address" required aria-invalid="<?php echo e($errors->has('address') ? 'true' : 'false'); ?>" aria-describedby="address-error"><?php echo e(old('address', $user->address)); ?></textarea>
                                    <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="address-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field">
                                    <label for="emergency_contact_name">Nama kontak darurat</label>
                                    <input id="emergency_contact_name" type="text" name="emergency_contact_name" value="<?php echo e(old('emergency_contact_name', $user->emergency_contact_name)); ?>" maxlength="255" autocomplete="off" required aria-invalid="<?php echo e($errors->has('emergency_contact_name') ? 'true' : 'false'); ?>" aria-describedby="emergency-contact-name-error">
                                    <?php $__errorArgs = ['emergency_contact_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="emergency-contact-name-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field">
                                    <label for="emergency_contact_phone">Telepon kontak darurat</label>
                                    <input id="emergency_contact_phone" type="tel" name="emergency_contact_phone" value="<?php echo e(old('emergency_contact_phone', $user->emergency_contact_phone)); ?>" maxlength="20" autocomplete="off" inputmode="tel" required aria-invalid="<?php echo e($errors->has('emergency_contact_phone') ? 'true' : 'false'); ?>" aria-describedby="emergency-contact-phone-error">
                                    <?php $__errorArgs = ['emergency_contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="emergency-contact-phone-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field">
                                    <label for="blood_type">Golongan darah</label>
                                    <select id="blood_type" name="blood_type">
                                        <option value="">Belum diketahui</option>
                                        <?php $__currentLoopData = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bloodType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($bloodType); ?>" <?php echo e(old('blood_type', $user->blood_type) === $bloodType ? 'selected' : ''); ?>><?php echo e($bloodType); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php $__errorArgs = ['blood_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-field form-field-wide">
                                    <label for="medical_history">Riwayat penyakit</label>
                                    <textarea id="medical_history" name="medical_history" rows="4" maxlength="4000" placeholder="Isi riwayat penyakit, alergi, atau obat rutin jika ada"><?php echo e(old('medical_history', $user->medical_history)); ?></textarea>
                                    <?php $__errorArgs = ['medical_history'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="medical-history-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            <?php endif; ?>
                            <button class="button button-primary" type="submit">Simpan perubahan</button>
                        </form>
                    </section>
                </div>
            </main>
            <footer class="clinic-footer profile-footer">
                <span>© 2026 Klinik UNPAM. Hak cipta dilindungi.</span>
            </footer>
        </div>
    </body>
</html>
<?php /**PATH C:\laragon\www\Klinik_Unpam\resources\views/profile.blade.php ENDPATH**/ ?>