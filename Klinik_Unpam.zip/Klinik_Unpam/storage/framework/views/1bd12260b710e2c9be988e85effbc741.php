<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#edf3fc">
        <title>Masuk | Klinik UNPAM</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
    </head>
    <body class="auth-page">
        <a class="skip-link" href="#auth-form">Lewati ke formulir masuk</a>
        <main class="auth-shell auth-shell-login">
            <aside class="auth-aside" aria-label="Informasi Klinik UNPAM">
                <a class="brand" href="<?php echo e(route('landing')); ?>" aria-label="Klinik UNPAM, halaman utama">
                    <span class="brand-mark" aria-hidden="true">+</span>
                    <span><strong>Klinik UNPAM</strong></span>
                </a>
                <div class="aside-copy">
                    <h1>Selamat datang</h1>
                    <p>Masuk dengan akun Anda untuk melanjutkan layanan kesehatan di Klinik UNPAM.</p>
                </div>
            </aside>

            <section class="auth-content" aria-labelledby="form-title">
                <div class="mobile-brand">
                    <span class="brand-mark" aria-hidden="true">+</span>
                    <strong>Klinik UNPAM</strong>
                </div>
                <div class="form-heading">
                    <h2 id="form-title">Masuk ke akun</h2>
                </div>

                <?php if($errors->any()): ?>
                    <div class="alert alert-error" role="alert" tabindex="-1">
                        <strong>Periksa kembali data Anda.</strong>
                        <span><?php echo e($errors->first()); ?></span>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success" role="status"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <form id="auth-form" class="auth-form" method="POST" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="field">
                        <label for="email">Alamat email</label>
                        <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" placeholder="nama@email.com" autocomplete="email" inputmode="email" required autofocus aria-invalid="<?php echo e($errors->has('email') ? 'true' : 'false'); ?>" aria-describedby="email-error">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="email-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="field">
                        <label for="password">Kata sandi</label>
                        <div class="password-field">
                            <input type="password" name="password" id="password" placeholder="Masukkan kata sandi" autocomplete="current-password" required aria-invalid="<?php echo e($errors->has('password') ? 'true' : 'false'); ?>" aria-describedby="password-error">
                            <button class="password-toggle" type="button" data-toggle-password="password" aria-label="Tampilkan kata sandi" aria-pressed="false">
                                <svg class="password-eye" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                <svg class="password-eye-off" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15.8 15.8 0 0 1-3 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.5 10.5 0 0 0 4-.8"/></svg>
                            </button>
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error" id="password-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <label class="remember-row" for="remember">
                        <input type="checkbox" name="remember" id="remember" value="1">
                        <span>Ingat saya</span>
                    </label>
                    <button class="submit-button" type="submit">Masuk <span aria-hidden="true">→</span></button>
                </form>

                <div class="login-register-action">
                    <span>Belum punya akun?</span>
                    <a href="<?php echo e(route('register')); ?>">Daftar</a>
                </div>

                <div class="login-reset-action">
                    <span>Lupa kata sandi?</span>
                    <details id="reset-password" class="login-password-reset" <?php if($errors->hasAny(['reset_email', 'current_password', 'registration_code', 'password'])): ?> open <?php endif; ?>>
                        <summary>Ubah kata sandi</summary>
                        <form class="auth-form reset-password-form" method="POST" action="<?php echo e(route('login.password.update')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="field">
                                <label for="reset-email">Email akun</label>
                                <input type="email" id="reset-email" name="email" value="<?php echo e(old('reset_email')); ?>" autocomplete="email" required>
                                <?php $__errorArgs = ['reset_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="field">
                                <label for="reset-role">Jenis akun</label>
                                <select id="reset-role" name="role" required>
                                    <option value="pasien" <?php echo e(old('reset_role', 'pasien') === 'pasien' ? 'selected' : ''); ?>>Pasien</option>
                                    <option value="dokter" <?php echo e(old('reset_role') === 'dokter' ? 'selected' : ''); ?>>Dokter</option>
                                    <option value="apoteker" <?php echo e(old('reset_role') === 'apoteker' ? 'selected' : ''); ?>>Apoteker</option>
                                    <option value="suster" <?php echo e(old('reset_role') === 'suster' ? 'selected' : ''); ?>>Perawat</option>
                                </select>
                            </div>
                            <div class="field">
                                <label for="reset-current-password">Kata sandi saat ini</label>
                                <div class="password-field">
                                    <input type="password" id="reset-current-password" name="current_password" autocomplete="current-password" required>
                                    <button class="password-toggle" type="button" data-toggle-password="reset-current-password" aria-label="Tampilkan kata sandi" aria-pressed="false">
                                        <svg class="password-eye" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                        <svg class="password-eye-off" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15.8 15.8 0 0 1-3 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.5 10.5 0 0 0 4-.8"/></svg>
                                    </button>
                                </div>
                                <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="field staff-reset-code" <?php if(old('reset_role', 'pasien') === 'pasien'): ?> hidden <?php endif; ?>>
                                <label for="reset-registration-code">Kode verifikasi staf</label>
                                <input type="password" id="reset-registration-code" name="registration_code" autocomplete="off" <?php if(old('reset_role', 'pasien') !== 'pasien'): ?> required <?php endif; ?>>
                                <?php $__errorArgs = ['registration_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="field">
                                <label for="reset-new-password">Kata sandi baru <span>(min. 10 karakter)</span></label>
                                <div class="password-field">
                                    <input type="password" id="reset-new-password" name="password" autocomplete="new-password" minlength="10" required>
                                    <button class="password-toggle" type="button" data-toggle-password="reset-new-password" aria-label="Tampilkan kata sandi" aria-pressed="false">
                                        <svg class="password-eye" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                        <svg class="password-eye-off" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15.8 15.8 0 0 1-3 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.5 10.5 0 0 0 4-.8"/></svg>
                                    </button>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="field">
                                <label for="reset-password-confirmation">Ulangi kata sandi baru</label>
                                <div class="password-field">
                                    <input type="password" id="reset-password-confirmation" name="password_confirmation" autocomplete="new-password" minlength="10" required>
                                    <button class="password-toggle" type="button" data-toggle-password="reset-password-confirmation" aria-label="Tampilkan kata sandi" aria-pressed="false">
                                        <svg class="password-eye" viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
                                        <svg class="password-eye-off" viewBox="0 0 24 24" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A10.7 10.7 0 0 1 12 5c6.4 0 10 7 10 7a15.8 15.8 0 0 1-3 3.8M6.2 6.2C3.5 8 2 12 2 12s3.6 7 10 7a10.5 10.5 0 0 0 4-.8"/></svg>
                                    </button>
                                </div>
                            </div>
                            <button class="submit-button" type="submit">Simpan perubahan</button>
                        </form>
                    </details>
                </div>

            </section>
        </main>
        <script>
            document.querySelectorAll('[data-toggle-password]').forEach((toggleButton) => {
                toggleButton.addEventListener('click', () => {
                    const passwordInput = document.getElementById(toggleButton.dataset.togglePassword);
                    const isVisible = passwordInput.type === 'text';

                    passwordInput.type = isVisible ? 'password' : 'text';
                    toggleButton.setAttribute('aria-pressed', String(!isVisible));
                    toggleButton.setAttribute('aria-label', isVisible ? 'Tampilkan kata sandi' : 'Sembunyikan kata sandi');
                    toggleButton.querySelector('.password-eye').hidden = !isVisible;
                    toggleButton.querySelector('.password-eye-off').hidden = isVisible;
                });
            });

            const resetRole = document.querySelector('#reset-role');
            const staffResetCode = document.querySelector('.staff-reset-code');
            const staffResetInput = document.querySelector('#reset-registration-code');

            const toggleStaffResetCode = () => {
                const staffRoleSelected = resetRole.value !== 'pasien';
                staffResetCode.hidden = !staffRoleSelected;
                staffResetInput.required = staffRoleSelected;
            };

            resetRole.addEventListener('change', toggleStaffResetCode);
            toggleStaffResetCode();
        </script>
    </body>
</html>
<?php /**PATH C:\laragon\www\Klinik_Unpam\resources\views/auth/login.blade.php ENDPATH**/ ?>