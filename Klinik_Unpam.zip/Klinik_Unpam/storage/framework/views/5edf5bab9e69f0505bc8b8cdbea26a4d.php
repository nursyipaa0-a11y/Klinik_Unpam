<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#0b4fb3">
        <title>Dashboard <?php echo e($roleLabel); ?> | Klinik UNPAM</title>
        <link rel="stylesheet" href="<?php echo e(asset('css/clinic-ui.css')); ?>">
    </head>
    <body class="clinic-ui">
        <div class="clinic-shell">
            <header class="clinic-header">
                <a class="clinic-brand" href="<?php echo e(route('dashboard')); ?>">
                    <span class="clinic-brand-mark" aria-hidden="true">+</span>
                    <span><strong>Klinik UNPAM</strong><small>Portal layanan klinik</small></span>
                </a>
                <nav class="clinic-nav" aria-label="Navigasi utama">
                    <a class="active" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
                    <a href="#clinic-workflow">Antrean &amp; kunjungan</a>
                    <?php if(in_array($user->role, ['dokter', 'apoteker'], true)): ?>
                        <a href="#prescriptions">Resep</a>
                    <?php endif; ?>
                </nav>
                <div class="clinic-account">
                    <div class="clinic-account-copy">
                        <strong><?php echo e($user->name); ?></strong>
                        <span><?php echo e($roleLabel); ?></span>
                    </div>
                    <a class="clinic-avatar" href="<?php echo e(route('profile')); ?>" aria-label="Akun <?php echo e($user->name); ?>"><?php echo e(strtoupper(substr($user->name, 0, 2))); ?></a>
                </div>
            </header>

            <main class="clinic-main">
                <section class="welcome-panel">
                    <div>
                        <p class="eyebrow">DASHBOARD <?php echo e(strtoupper($roleLabel)); ?></p>
                        <h1>Halo, <?php echo e($user->name); ?></h1>
                        <p class="welcome-copy">Pantau antrean dan pembaruan layanan klinik dari satu tempat.</p>
                    </div>
                    <div class="live-indicator"><span aria-hidden="true"></span> Data diperbarui otomatis</div>
                </section>

                <section class="summary-grid" aria-label="Ringkasan operasional">
                    <article class="summary-card"><span>Total kunjungan</span><strong data-count="total"><?php echo e($visitCounts['total']); ?></strong><small>Data antrean tersimpan</small></article>
                    <article class="summary-card"><span>Menunggu dokter</span><strong data-count="menunggu_dokter"><?php echo e($visitCounts['menunggu_dokter']); ?></strong><small>Data pasien tersimpan, siap dipanggil</small></article>
                    <article class="summary-card"><span>Dalam konsultasi</span><strong data-count="konsultasi"><?php echo e($visitCounts['konsultasi']); ?></strong><small>Sedang ditangani dokter</small></article>
                    <?php if($user->role === 'pasien'): ?>
                        <article class="summary-card"><span>Riwayat kunjungan</span><strong><?php echo e($visitCounts['riwayat']); ?></strong><small>Kunjungan selesai atau dibatalkan</small></article>
                    <?php endif; ?>
                    <?php if(in_array($user->role, ['dokter', 'apoteker'], true)): ?>
                        <article class="summary-card"><span>Total resep</span><strong data-count="resep_total"><?php echo e($prescriptionCounts['total']); ?></strong><small>Resep tersimpan</small></article>
                        <article class="summary-card"><span>Resep menunggu</span><strong data-count="resep_menunggu"><?php echo e($prescriptionCounts['menunggu']); ?></strong><small>Menunggu apoteker</small></article>
                        <article class="summary-card"><span>Resep diproses</span><strong data-count="resep_diproses"><?php echo e($prescriptionCounts['diproses']); ?></strong><small>Sedang disiapkan</small></article>
                    <?php endif; ?>
                </section>

                <?php echo $__env->make('components.clinic-workflow', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </main>

            <footer class="clinic-footer">
                <span>Klinik UNPAM · Informasi operasional akun <?php echo e($roleLabel); ?></span>
            </footer>
        </div>
        <script src="<?php echo e(asset('js/clinic-workflow.js')); ?>" defer></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\Klinik_Unpam\resources\views/dashboard.blade.php ENDPATH**/ ?>