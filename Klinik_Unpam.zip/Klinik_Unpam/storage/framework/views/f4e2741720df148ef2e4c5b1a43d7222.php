<section id="clinic-workflow" class="workflow-section" aria-live="polite" data-poll-url="<?php echo e(route('dashboard.workflow')); ?>" data-count-total="<?php echo e($visitCounts['total']); ?>" data-count-menunggu-verifikasi="<?php echo e($visitCounts['menunggu_verifikasi']); ?>" data-count-menunggu-dokter="<?php echo e($visitCounts['menunggu_dokter']); ?>" data-count-konsultasi="<?php echo e($visitCounts['konsultasi']); ?>" data-count-resep-total="<?php echo e($prescriptionCounts['total']); ?>" data-count-resep-menunggu="<?php echo e($prescriptionCounts['menunggu']); ?>" data-count-resep-diproses="<?php echo e($prescriptionCounts['diproses']); ?>">
    <?php if($errors->any()): ?>
        <div class="notice notice-error" role="alert"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>
    <?php if(session('success')): ?>
        <div class="notice notice-success" role="status"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="notice notice-error" role="alert"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if($user->role === 'pasien'): ?>
        <section class="panel booking-panel" aria-labelledby="booking-title">
            <div class="panel-heading">
                <div><p class="eyebrow">LAYANAN PASIEN</p><h2 id="booking-title">Ambil nomor antrean</h2></div>
                <span class="panel-icon" aria-hidden="true">01</span>
            </div>
            <p class="panel-copy">Pilih poli. Permintaan Anda langsung tersimpan dan diterima oleh perawat.</p>
            <form class="clinic-form booking-form" method="POST" action="<?php echo e(route('visits.store')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-field">
                    <label for="service">Pilih poli</label>
                    <select id="service" name="service" required>
                        <option value="">Pilih poli</option>
                        <option value="Poli Umum">Poli Umum</option>
                        <option value="Poli Gigi">Poli Gigi</option>
                        <option value="Poli KIA">Poli Kesehatan Ibu dan Anak</option>
                        <option value="Poli Ortopedi">Poli Ortopedi</option>
                    </select>
                    <?php $__errorArgs = ['service'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-field form-field-wide">
                    <label for="complaint">Keluhan/catatan untuk perawat</label>
                    <textarea id="complaint" name="complaint" rows="3" maxlength="2000" placeholder="Tuliskan informasi yang perlu diketahui perawat"><?php echo e(old('complaint')); ?></textarea>
                    <?php $__errorArgs = ['complaint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <button class="button button-primary" type="submit">Minta nomor antrean</button>
            </form>
        </section>

        <section class="panel patient-queue-panel" aria-labelledby="patient-queue-title">
            <div class="panel-heading">
                <div><p class="eyebrow">ANTREAN ANDA</p><h2 id="patient-queue-title">Nomor dan perkiraan panggilan</h2></div>
                <span class="panel-count"><?php echo e($visits->count()); ?> antrean aktif</span>
            </div>
            <?php if($visits->isEmpty()): ?>
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">01</span><div><strong>Belum ada antrean aktif</strong><p>Setelah memilih poli, nomor antrean dan perkiraan panggilan akan tampil di sini.</p></div></div>
            <?php else: ?>
                <div class="patient-queue-list">
                    <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $patientQueueStatus = match ($visit->status) {
                                'menunggu_verifikasi', 'menunggu_dokter' => 'Menunggu dipanggil dokter',
                                'dipanggil' => 'Dokter sedang memanggil Anda',
                                'konsultasi' => 'Sedang diperiksa dokter',
                                default => $visit->status,
                            };
                        ?>
                        <article class="patient-queue-card">
                            <div class="patient-queue-heading">
                                <div>
                                    <span class="queue-number"><?php echo e($visit->service); ?></span>
                                    <h3><?php echo e($visit->queue_number); ?></h3>
                                    <p class="visit-meta">Nomor antrean poli Anda · <?php echo e($visit->created_at->format('d M Y, H:i')); ?></p>
                                </div>
                                <span class="status-pill"><?php echo e($patientQueueStatus); ?></span>
                            </div>
                            <?php if($visit->status === 'menunggu_verifikasi' || $visit->status === 'menunggu_dokter'): ?>
                                <p class="call-estimate"><strong>Perkiraan panggilan:</strong> <?php echo e($queueCallEstimates[$visit->id] ?? 'Sedang menghitung antrean.'); ?></p>
                            <?php elseif($visit->status === 'dipanggil'): ?>
                                <p class="call-estimate call-estimate-active"><strong>Silakan menuju ruang pemeriksaan.</strong> <?php echo e($queueCallEstimates[$visit->id] ?? ''); ?></p>
                            <?php elseif($visit->status === 'konsultasi'): ?>
                                <p class="call-estimate"><strong>Status:</strong> <?php echo e($queueCallEstimates[$visit->id] ?? 'Sedang diperiksa dokter.'); ?></p>
                            <?php endif; ?>
                            <?php if($visit->doctor && $visit->status !== 'menunggu_dokter'): ?>
                                <p class="visit-meta">Dokter: <?php echo e($visit->doctor->name); ?></p>
                            <?php endif; ?>
                            <?php if($visit->prescription): ?>
                                <?php if($visit->prescription->status === 'stok_tidak_cukup'): ?>
                                    <div class="patient-pharmacy-note"><strong>Apotek sedang memastikan ketersediaan obat.</strong><span>Rincian obat ditangani tenaga klinik.</span></div>
                                <?php elseif(in_array($visit->prescription->status, ['menunggu', 'diproses'], true)): ?>
                                    <div class="patient-pharmacy-note"><strong>Permintaan obat diterima apotek.</strong><span>Apotek sedang menyiapkan obat Anda.</span></div>
                                <?php elseif($visit->prescription->status === 'siap_diambil'): ?>
                                    <div class="patient-pharmacy-note"><strong>Obat siap diambil di apotek.</strong><span>Silakan ke loket apotek untuk mengambil obat dan melakukan pembayaran.</span></div>
                                    <?php if($visit->payment): ?>
                                        <div class="patient-payment"><span>Total pembayaran</span><strong>Rp <?php echo e(number_format((float) $visit->payment->amount, 0, ',', '.')); ?></strong><span>Status: <?php echo e($visit->payment->status === 'dibayar' ? 'Sudah dibayar' : 'Belum dibayar'); ?></span></div>
                                    <?php endif; ?>
                                <?php elseif($visit->prescription->status === 'diserahkan'): ?>
                                    <div class="patient-pharmacy-note"><strong>Pengambilan obat selesai.</strong><span>Pembayaran: <?php echo e($visit->payment?->status === 'dibayar' ? 'Lunas' : 'Belum tercatat'); ?>.</span></div>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php if(in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true)): ?>
                                <form method="POST" action="<?php echo e(route('visits.status', $visit)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="dibatalkan">
                                    <button class="button button-outline" type="submit">Batalkan antrean</button>
                                </form>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($user->role !== 'pasien'): ?>
    <section class="panel" aria-labelledby="visits-title">
        <div class="panel-heading">
            <div><p class="eyebrow">ALUR PELAYANAN</p><h2 id="visits-title">Antrean dan data pasien</h2></div>
            <span class="panel-count"><?php echo e($visits->count()); ?> kunjungan</span>
        </div>

        <?php if($visits->isEmpty()): ?>
            <div class="empty-state"><span class="empty-icon" aria-hidden="true">01</span><div><strong>Belum ada antrean</strong><p>Data permintaan pasien akan muncul di sini setelah disimpan.</p></div></div>
        <?php else: ?>
            <div class="visit-list">
                <?php $__currentLoopData = $visits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $visitStatusLabel = match ($visit->status) {
                            'menunggu_verifikasi', 'menunggu_dokter' => 'Menunggu dipanggil dokter',
                            'dipanggil' => 'Dokter memanggil pasien',
                            'konsultasi' => 'Sedang diperiksa dokter',
                            'selesai' => 'Pemeriksaan selesai',
                            'dibatalkan' => 'Permintaan dibatalkan',
                            default => $visit->status,
                        };
                    ?>
                    <article class="visit-card">
                        <div class="visit-card-top">
                            <div>
                                <p class="queue-number">Nomor antrean poli: <?php echo e($visit->queue_number); ?></p>
                                <h3><?php echo e($visit->service); ?></h3>
                                <p class="visit-meta">Pasien: <?php echo e($visit->patient->name); ?> · Dibuat <?php echo e($visit->created_at->format('d M Y, H:i')); ?></p>
                            </div>
                            <span class="status-pill"><?php echo e($visitStatusLabel); ?></span>
                        </div>

                        <?php if($visit->complaint && in_array($user->role, ['pasien', 'dokter', 'suster'], true)): ?>
                            <p class="visit-note"><strong>Catatan pasien:</strong> <?php echo e($visit->complaint); ?></p>
                        <?php endif; ?>
                        <?php if($user->role === 'suster'): ?>
                            <div class="patient-details" aria-label="Data pasien">
                                <p class="visit-meta"><strong>Data pasien</strong></p>
                                <dl class="patient-details-list">
                                    <div><dt>NIK</dt><dd><?php echo e($visit->patient->national_id ?: 'Belum diisi'); ?></dd></div>
                                    <div><dt>Tanggal lahir</dt><dd><?php echo e($visit->patient->date_of_birth?->format('d M Y') ?? 'Belum diisi'); ?></dd></div>
                                    <div><dt>Jenis kelamin</dt><dd><?php echo e($visit->patient->gender ?: 'Belum diisi'); ?></dd></div>
                                    <div><dt>Telepon</dt><dd><?php echo e($visit->patient->phone ?: 'Belum diisi'); ?></dd></div>
                                    <div><dt>Alamat</dt><dd><?php echo e($visit->patient->address ?: 'Belum diisi'); ?></dd></div>
                                    <div><dt>Kontak darurat</dt><dd><?php echo e($visit->patient->emergency_contact_name ?: 'Belum diisi'); ?> · <?php echo e($visit->patient->emergency_contact_phone ?: 'Belum diisi'); ?></dd></div>
                                    <div><dt>Golongan darah</dt><dd><?php echo e($visit->patient->blood_type ?: 'Belum diketahui'); ?></dd></div>
                                    <div class="patient-details-wide"><dt>Riwayat penyakit</dt><dd><?php echo e($visit->patient->medical_history ?: 'Belum diisi pasien'); ?></dd></div>
                                </dl>
                            </div>
                        <?php endif; ?>
                        <?php if($visit->doctor && in_array($user->role, ['pasien', 'dokter', 'suster'], true)): ?>
                            <p class="visit-meta">Dokter: <?php echo e($visit->doctor->name); ?></p>
                        <?php endif; ?>

                        <?php if($user->role === 'pasien' && $visit->prescription): ?>
                            <?php if($visit->prescription->status === 'stok_tidak_cukup'): ?>
                                <div class="patient-pharmacy-note"><strong>Apotek sedang memastikan ketersediaan obat.</strong><span>Silakan pantau pembaruan. Rincian obat ditangani tenaga klinik.</span></div>
                            <?php elseif(in_array($visit->prescription->status, ['menunggu', 'diproses'], true)): ?>
                                <div class="patient-pharmacy-note"><strong>Permintaan obat sudah diterima apotek.</strong><span>Apotek sedang menyiapkan obat Anda.</span></div>
                            <?php elseif($visit->prescription->status === 'siap_diambil'): ?>
                                <div class="patient-pharmacy-note"><strong>Obat siap diambil di apotek.</strong><span>Silakan ke loket apotek untuk mengambil obat dan melakukan pembayaran.</span></div>
                                <?php if($visit->payment): ?>
                                    <div class="patient-payment"><span>Total pembayaran</span><strong>Rp <?php echo e(number_format((float) $visit->payment->amount, 0, ',', '.')); ?></strong><span>Status: <?php echo e($visit->payment->status === 'dibayar' ? 'Sudah dibayar' : 'Belum dibayar'); ?></span></div>
                                <?php endif; ?>
                            <?php elseif($visit->prescription->status === 'diserahkan'): ?>
                                <div class="patient-pharmacy-note"><strong>Pengambilan obat selesai.</strong><span>Pembayaran: <?php echo e($visit->payment?->status === 'dibayar' ? 'Lunas' : 'Belum tercatat'); ?>.</span></div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <div class="visit-actions">
                            <?php if($user->role === 'pasien' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true)): ?>
                                <form method="POST" action="<?php echo e(route('visits.status', $visit)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="dibatalkan">
                                    <button class="button button-outline" type="submit">Batalkan antrean</button>
                                </form>
                            <?php elseif($user->role === 'dokter' && in_array($visit->status, ['menunggu_verifikasi', 'menunggu_dokter'], true)): ?>
                                <form method="POST" action="<?php echo e(route('visits.status', $visit)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="dipanggil">
                                    <button class="button button-primary" type="submit">Panggil pasien</button>
                                </form>
                            <?php elseif($user->role === 'dokter' && $visit->status === 'dipanggil' && $visit->assigned_doctor_id === $user->id): ?>
                                <form method="POST" action="<?php echo e(route('visits.status', $visit)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="konsultasi">
                                    <button class="button button-primary" type="submit">Mulai pemeriksaan</button>
                                </form>
                            <?php elseif($user->role === 'dokter' && $visit->status === 'konsultasi' && $visit->assigned_doctor_id === $user->id): ?>
                                <?php if(! $visit->prescription): ?>
                                    <details class="action-details">
                                        <summary class="button button-outline">Tulis resep</summary>
                                        <form class="clinic-form prescription-form" method="POST" action="<?php echo e(route('visits.prescriptions.store', $visit)); ?>" data-max-prescription-items="10">
                                            <?php echo csrf_field(); ?>
                                            <div class="prescription-item-list" data-prescription-items>
                                                <div class="prescription-item-row">
                                                    <div class="form-field">
                                                        <label>Obat</label>
                                                        <select name="items[0][medicine_id]" required>
                                                            <option value="">Pilih obat</option>
                                                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($medicine->id); ?>"><?php echo e($medicine->name); ?> — <?php echo e($medicine->form); ?>, <?php echo e($medicine->strength); ?> (stok <?php echo e($medicine->stock); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-field">
                                                        <label>Jumlah obat</label>
                                                        <input type="number" name="items[0][quantity]" min="1" max="100" value="1" required>
                                                    </div>
                                                    <div class="form-field form-field-wide">
                                                        <label>Aturan pakai dari dokter</label>
                                                        <input type="text" name="items[0][dosage]" maxlength="255" placeholder="Tulis aturan pakai pasien" required>
                                                    </div>
                                                </div>
                                            </div>
                                            <p class="visit-meta" data-prescription-item-count aria-live="polite">1 dari 10 jenis obat</p>
                                            <button class="button button-outline" type="button" data-add-prescription-item>Tambah obat</button>
                                            <template data-prescription-item-template>
                                                <div class="prescription-item-row">
                                                    <div class="form-field">
                                                        <label>Obat</label>
                                                        <select name="items[__INDEX__][medicine_id]" required>
                                                            <option value="">Pilih obat</option>
                                                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($medicine->id); ?>"><?php echo e($medicine->name); ?> — <?php echo e($medicine->form); ?>, <?php echo e($medicine->strength); ?> (stok <?php echo e($medicine->stock); ?>)</option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-field">
                                                        <label>Jumlah obat</label>
                                                        <input type="number" name="items[__INDEX__][quantity]" min="1" max="100" value="1" required>
                                                    </div>
                                                    <div class="form-field form-field-wide">
                                                        <label>Aturan pakai dari dokter</label>
                                                        <input type="text" name="items[__INDEX__][dosage]" maxlength="255" placeholder="Tulis aturan pakai pasien" required>
                                                    </div>
                                                    <button class="button button-outline" type="button" data-remove-prescription-item>Hapus obat ini</button>
                                                </div>
                                            </template>
                                            <button class="button button-primary" type="submit">Kirim resep ke apotek</button>
                                        </form>
                                    </details>
                                <?php else: ?>
                                    <p class="visit-meta">Resep sudah dikirim ke apotek untuk diproses.</p>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('visits.status', $visit)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="selesai">
                                    <button class="button button-primary" type="submit" <?php echo e($visit->prescription ? '' : 'disabled'); ?>>Selesaikan pemeriksaan</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if($user->role === 'pasien'): ?>
        <section class="panel history-panel" aria-labelledby="history-title">
            <div class="panel-heading">
                <div><p class="eyebrow">KUNJUNGAN ANDA</p><h2 id="history-title">Riwayat pasien</h2></div>
                <span class="panel-count"><?php echo e($visitHistory->count()); ?> riwayat</span>
            </div>
            <?php if($visitHistory->isEmpty()): ?>
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">03</span><div><strong>Riwayat masih kosong</strong><p>Kunjungan yang selesai atau dibatalkan akan tersimpan di sini.</p></div></div>
            <?php else: ?>
                <div class="history-scroll" role="region" aria-label="Daftar riwayat kunjungan pasien" tabindex="0">
                    <div class="visit-list">
                        <?php $__currentLoopData = $visitHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $historyVisit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <article class="visit-card history-card">
                                <div class="visit-card-top">
                                    <div>
                                        <p class="queue-number">Nomor antrean poli: <?php echo e($historyVisit->queue_number); ?></p>
                                        <h3><?php echo e($historyVisit->service); ?></h3>
                                        <p class="visit-meta"><?php echo e($historyVisit->created_at->format('d M Y, H:i')); ?></p>
                                    </div>
                                    <span class="status-pill"><?php echo e($historyVisit->status === 'selesai' ? 'Pemeriksaan selesai' : 'Dibatalkan'); ?></span>
                                </div>
                                <?php if($historyVisit->doctor): ?>
                                    <p class="visit-meta">Dokter: <?php echo e($historyVisit->doctor->name); ?></p>
                                <?php endif; ?>
                                <?php if($historyVisit->prescription): ?>
                                    <p class="visit-meta">Status apotek: <?php echo e(match ($historyVisit->prescription->status) {
                                        'stok_tidak_cukup' => 'Apotek sedang memastikan ketersediaan obat',
                                        'menunggu' => 'Diterima apotek',
                                        'diproses' => 'Obat sedang disiapkan',
                                        'siap_diambil' => 'Siap diambil di apotek',
                                        'diserahkan' => 'Pengambilan selesai',
                                        default => 'Belum ada pembaruan',
                                    }); ?></p>
                                <?php endif; ?>
                                <?php if($historyVisit->payment): ?>
                                    <p class="visit-meta">Pembayaran: <?php echo e($historyVisit->payment->status === 'dibayar' ? 'Lunas' : 'Belum dibayar'); ?></p>
                                <?php endif; ?>
                            </article>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if(in_array($user->role, ['dokter', 'apoteker'], true)): ?>
        <section id="prescriptions" class="panel" aria-labelledby="prescriptions-title">
            <div class="panel-heading">
                <div><p class="eyebrow">AKSES TENAGA KLINIK</p><h2 id="prescriptions-title"><?php echo e($user->role === 'dokter' ? 'Resep yang saya tulis' : 'Resep masuk apotek'); ?></h2></div>
                <span class="panel-count"><?php echo e($prescriptions->count()); ?> resep</span>
            </div>
            <?php if($prescriptions->isEmpty()): ?>
                <div class="empty-state"><span class="empty-icon" aria-hidden="true">02</span><div><strong>Belum ada resep</strong><p>Resep tampil setelah dokter mengirimkannya dari pemeriksaan pasien.</p></div></div>
            <?php else: ?>
                <div class="prescription-list">
                    <?php $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $prescriptionStatusLabel = match ($prescription->status) {
                                'menunggu' => 'Baru masuk',
                                'stok_tidak_cukup' => 'Stok tidak cukup',
                                'diproses' => 'Sedang disiapkan',
                                'siap_diambil' => 'Siap diambil',
                                'diserahkan' => 'Sudah diserahkan',
                                default => $prescription->status,
                            };
                        ?>
                        <article class="prescription-card">
                            <div class="visit-card-top">
                                <div>
                                    <p class="queue-number">Antrean <?php echo e($prescription->visit->queue_number); ?></p>
                                    <h3><?php echo e($prescription->visit->patient->name); ?> · <?php echo e($prescription->visit->service); ?></h3>
                                    <p class="visit-meta">Dokter: <?php echo e($prescription->doctor->name); ?> · <?php echo e($prescription->created_at->format('d M Y, H:i')); ?></p>
                                </div>
                                <span class="status-pill"><?php echo e($prescriptionStatusLabel); ?></span>
                            </div>
                            <div class="prescription-drugs">
                                <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="prescription-drug">
                                        <strong><?php echo e($item->medicine->name); ?> — <?php echo e($item->medicine->form); ?>, <?php echo e($item->medicine->strength); ?></strong>
                                        <span>Jumlah <?php echo e($item->quantity); ?> <?php echo e($item->medicine->unit); ?> · <?php echo e($item->dosage); ?></span>
                                        <small>Stok kini: <?php echo e($item->medicine->stock); ?></small>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php if($user->role === 'apoteker'): ?>
                                <?php if(in_array($prescription->status, ['menunggu', 'stok_tidak_cukup'], true)): ?>
                                    <form method="POST" action="<?php echo e(route('prescriptions.process', $prescription)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="button button-primary" type="submit">Cek stok dan siapkan resep</button>
                                    </form>
                                <?php elseif($prescription->status === 'diproses'): ?>
                                    <form method="POST" action="<?php echo e(route('prescriptions.status', $prescription)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="siap_diambil">
                                        <button class="button button-primary" type="submit">Beri tahu siap diambil</button>
                                    </form>
                                <?php elseif($prescription->status === 'siap_diambil' && $prescription->visit->payment?->status === 'belum_bayar'): ?>
                                    <div class="pharmacy-payment"><strong>Tagihan pasien: Rp <?php echo e(number_format((float) $prescription->visit->payment->amount, 0, ',', '.')); ?></strong><span>Catat pembayaran setelah pasien membayar di loket.</span></div>
                                    <form method="POST" action="<?php echo e(route('payments.record', $prescription->visit->payment)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button class="button button-primary" type="submit">Konfirmasi pembayaran tunai</button>
                                    </form>
                                <?php elseif($prescription->status === 'siap_diambil' && $prescription->visit->payment?->status === 'dibayar'): ?>
                                    <div class="pharmacy-payment"><strong>Pembayaran diterima</strong><span>Rp <?php echo e(number_format((float) $prescription->visit->payment->amount, 0, ',', '.')); ?> · Tunai</span></div>
                                    <form method="POST" action="<?php echo e(route('prescriptions.status', $prescription)); ?>">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                        <input type="hidden" name="status" value="diserahkan">
                                        <button class="button button-primary" type="submit">Serahkan obat ke pasien</button>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if($user->role === 'apoteker'): ?>
        <section class="panel" aria-labelledby="inventory-title">
            <div class="panel-heading">
                <div><p class="eyebrow">PERSEDIAAN</p><h2 id="inventory-title">Daftar stok obat</h2></div>
                <span class="panel-count"><?php echo e($medicines->count()); ?> jenis obat</span>
            </div>
            <details class="medicine-create-details">
                <summary class="button button-primary">Tambah jenis obat</summary>
                <form class="clinic-form medicine-create-form" method="POST" action="<?php echo e(route('medicines.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-field">
                        <label for="medicine-name">Nama obat</label>
                        <input id="medicine-name" type="text" name="name" maxlength="255" value="<?php echo e(old('name')); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="medicine-form">Bentuk obat</label>
                        <input id="medicine-form" type="text" name="form" maxlength="60" placeholder="Tablet, kapsul, sirup" value="<?php echo e(old('form')); ?>" required>
                        <?php $__errorArgs = ['form'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="medicine-strength">Dosis/kekuatan</label>
                        <input id="medicine-strength" type="text" name="strength" maxlength="100" placeholder="Contoh: 500 mg" value="<?php echo e(old('strength')); ?>" required>
                        <?php $__errorArgs = ['strength'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="medicine-unit">Satuan stok</label>
                        <input id="medicine-unit" type="text" name="unit" maxlength="40" placeholder="tablet, kapsul, botol" value="<?php echo e(old('unit')); ?>" required>
                        <?php $__errorArgs = ['unit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="medicine-stock">Stok awal</label>
                        <input id="medicine-stock" type="number" name="stock" min="0" max="1000000" value="<?php echo e(old('stock', 0)); ?>" required>
                        <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-field">
                        <label for="medicine-price">Harga per satuan (Rp)</label>
                        <input id="medicine-price" type="number" name="unit_price" min="0.01" max="9999999999.99" step="0.01" value="<?php echo e(old('unit_price')); ?>" required>
                        <?php $__errorArgs = ['unit_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="field-error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <button class="button button-primary" type="submit">Simpan obat</button>
                </form>
            </details>
            <div class="inventory-list">
                <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medicine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="inventory-card">
                        <div>
                            <strong><?php echo e($medicine->name); ?></strong>
                            <span><?php echo e($medicine->form); ?> · <?php echo e($medicine->strength); ?> · Rp <?php echo e(number_format((float) $medicine->unit_price, 0, ',', '.')); ?>/<?php echo e($medicine->unit); ?></span>
                        </div>
                        <span class="stock-pill <?php echo e($medicine->stock < 5 ? 'stock-low' : ''); ?>">Stok <?php echo e($medicine->stock); ?> <?php echo e($medicine->unit); ?><?php echo e($medicine->stock < 5 ? ' · Perlu restock' : ''); ?></span>
                        <form class="restock-form" method="POST" action="<?php echo e(route('medicines.stock', $medicine)); ?>">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <label class="visually-hidden" for="restock-<?php echo e($medicine->id); ?>">Tambah stok <?php echo e($medicine->name); ?></label>
                            <input id="restock-<?php echo e($medicine->id); ?>" type="number" name="quantity" min="1" max="1000" value="10" required>
                            <button class="button button-outline" type="submit">Tambah stok</button>
                        </form>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
</section>
<?php /**PATH C:\laragon\www\Klinik_Unpam\resources\views/components/clinic-workflow.blade.php ENDPATH**/ ?>