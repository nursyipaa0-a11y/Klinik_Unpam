<?php

namespace Tests\Feature;

use App\Models\Prescription;
use App\Models\User;
use App\Models\Visit;
use Database\Seeders\ResetLocalDemoAccountsSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class AuthLoginTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_can_login_with_email_only(): void
    {
        $user = User::factory()->create([
            'name' => 'Pasien Klinik',
            'email' => 'nursyipaa0@gmail.com',
            'role' => 'pasien',
            'password' => 'chokky02',
        ]);

        $response = $this->from('/login')->post('/login', [
            'email' => 'nursyipaa0@gmail.com',
            'password' => 'chokky02',
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
        $this->get('/dashboard')->assertSee('Pasien Klinik');
    }

    public function test_login_and_registration_pages_render_the_new_layout(): void
    {
        $this->get('/login')
            ->assertOk()
            ->assertSee('Masuk ke akun')
            ->assertSee('Daftar')
            ->assertSee('Ubah kata sandi')
            ->assertDontSee('Registrasi pasien')
            ->assertDontSee('Akun demo untuk mencoba')
            ->assertDontSee('pasien.demo@klinik-unpam.test')
            ->assertDontSee('DokterDemo2026!')
            ->assertSee('id="reset-password"', false);
        $this->get('/register')
            ->assertOk()
            ->assertSee('Daftar akun')
            ->assertSee('NIK')
            ->assertSee('Tanggal lahir')
            ->assertSee('Nama kontak darurat');
    }

    public function test_local_demo_seeder_replaces_existing_accounts_with_all_roles(): void
    {
        $oldPatient = User::factory()->create(['email' => 'akun-lama@example.com']);
        $oldDoctor = User::factory()->create(['role' => 'dokter']);
        $oldVisit = Visit::factory()->create(['patient_id' => $oldPatient->id]);
        Prescription::factory()->create([
            'visit_id' => $oldVisit->id,
            'doctor_id' => $oldDoctor->id,
        ]);

        $this->seed(ResetLocalDemoAccountsSeeder::class);

        $this->assertDatabaseMissing('users', ['email' => 'akun-lama@example.com']);
        $this->assertDatabaseCount('users', 4);
        $this->assertDatabaseCount('visits', 0);
        $this->assertDatabaseCount('prescriptions', 0);

        $demoAccounts = [
            'pasien.demo@klinik-unpam.test' => ['pasien', 'PasienDemo2026!', 'Pasien'],
            'dokter.demo@klinik-unpam.test' => ['dokter', 'DokterDemo2026!', 'Dokter'],
            'apoteker.demo@klinik-unpam.test' => ['apoteker', 'ApotekerDemo2026!', 'Apoteker'],
            'perawat.demo@klinik-unpam.test' => ['suster', 'PerawatDemo2026!', 'Perawat'],
        ];

        foreach ($demoAccounts as $email => [$role, $password, $roleLabel]) {
            $user = User::query()->where('email', $email)->firstOrFail();

            $this->assertSame($role, $user->role);
            $this->assertTrue(Hash::check($password, $user->password));

            $this->post('/login', [
                'email' => $email,
                'password' => $password,
            ])->assertRedirect('/dashboard');
            $this->get('/dashboard')->assertViewIs('dashboard')->assertViewHas('roleLabel', $roleLabel);
            $this->post('/logout');
        }
    }

    public function test_patient_can_register_without_a_staff_number_and_reaches_patient_dashboard(): void
    {
        $nationalId = '3175091201990001';
        $response = $this->post('/register', [
            'name' => 'Pasien Baru',
            'email' => 'pasien@example.com',
            'phone' => '081234567890',
            'role' => 'pasien',
            'national_id' => $nationalId,
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Kesehatan No. 10, Tangerang Selatan',
            'emergency_contact_name' => 'Keluarga Pasien',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'O+',
            'medical_history' => 'Alergi udang',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertDatabaseHas('users', [
            'email' => 'pasien@example.com',
            'role' => 'pasien',
            'staff_number' => null,
            'national_id_hash' => User::nationalIdHash($nationalId),
            'gender' => 'Perempuan',
            'address' => 'Jl. Kesehatan No. 10, Tangerang Selatan',
            'emergency_contact_name' => 'Keluarga Pasien',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'O+',
            'medical_history' => 'Alergi udang',
        ]);
        $user = User::query()->where('email', 'pasien@example.com')->firstOrFail();
        $this->assertSame($nationalId, $user->national_id);
        $this->assertSame('1999-01-12', $user->date_of_birth->format('Y-m-d'));
        $this->assertNotSame($nationalId, DB::table('users')->where('id', $user->id)->value('national_id'));
        $this->assertAuthenticated();
        $this->get('/dashboard')->assertViewIs('dashboard')->assertSee('Pasien Baru');
    }

    public function test_patient_registration_requires_complete_identity_and_emergency_contact_data(): void
    {
        $response = $this->from('/register')->post('/register', [
            'name' => 'Pasien Baru',
            'email' => 'pasien@example.com',
            'role' => 'pasien',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/register')->assertSessionHasErrors([
            'national_id',
            'date_of_birth',
            'gender',
            'address',
            'emergency_contact_name',
            'emergency_contact_phone',
        ]);
        $this->assertDatabaseMissing('users', ['email' => 'pasien@example.com']);
    }

    public function test_patient_registration_rejects_a_national_id_that_is_already_registered(): void
    {
        $nationalId = '3175091201990001';
        User::factory()->create([
            'role' => 'pasien',
            'national_id' => $nationalId,
            'national_id_hash' => User::nationalIdHash($nationalId),
        ]);

        $response = $this->from('/register')->post('/register', [
            'name' => 'Pasien Kedua',
            'email' => 'pasien-kedua@example.com',
            'role' => 'pasien',
            'national_id' => $nationalId,
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Kesehatan No. 10',
            'emergency_contact_name' => 'Keluarga Pasien',
            'emergency_contact_phone' => '081298765432',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/register')->assertSessionHasErrors('national_id');
        $this->assertDatabaseMissing('users', ['email' => 'pasien-kedua@example.com']);
    }

    public function test_staff_registration_is_rejected_without_the_clinic_code(): void
    {
        Config::set('clinic.registration_codes.dokter', 'kode-dokter-rahasia');

        $response = $this->from('/register')->post('/register', [
            'name' => 'Dokter Baru',
            'email' => 'dokter@example.com',
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
            'registration_code' => 'kode-salah',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/register')->assertSessionHasErrors('registration_code');
        $this->assertDatabaseMissing('users', ['email' => 'dokter@example.com']);
        $this->assertFalse(session()->hasOldInput('registration_code'));
    }

    public function test_staff_can_register_with_a_valid_code_and_reaches_their_dashboard(): void
    {
        Config::set('clinic.registration_codes.dokter', 'kode-dokter-rahasia');

        $response = $this->post('/register', [
            'name' => 'Dokter Baru',
            'email' => 'dokter@example.com',
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
            'registration_code' => 'kode-dokter-rahasia',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/dashboard');
        $this->assertDatabaseHas('users', [
            'email' => 'dokter@example.com',
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
        ]);
        $this->get('/dashboard')->assertViewIs('dashboard')->assertViewHas('roleLabel', 'Dokter');
    }

    public function test_staff_number_must_be_unique_within_its_role(): void
    {
        Config::set('clinic.registration_codes.dokter', 'kode-dokter-rahasia');
        User::factory()->create([
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
        ]);

        $response = $this->from('/register')->post('/register', [
            'name' => 'Dokter Kedua',
            'email' => 'dokter-kedua@example.com',
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
            'registration_code' => 'kode-dokter-rahasia',
            'password' => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect('/register')->assertSessionHasErrors('staff_number');
        $this->assertDatabaseMissing('users', ['email' => 'dokter-kedua@example.com']);
    }

    public function test_each_role_reaches_its_matching_dashboard(): void
    {
        foreach ([
            'pasien' => 'Pasien',
            'dokter' => 'Dokter',
            'apoteker' => 'Apoteker',
            'suster' => 'Perawat',
        ] as $role => $roleLabel) {
            $user = User::factory()->create(['role' => $role]);

            $this->actingAs($user)->get('/dashboard')
                ->assertViewIs('dashboard')
                ->assertViewHas('roleLabel', $roleLabel);
        }
    }
}
