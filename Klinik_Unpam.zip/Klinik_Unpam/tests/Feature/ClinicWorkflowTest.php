<?php

namespace Tests\Feature;

use App\Models\Medicine;
use App\Models\Payment;
use App\Models\Prescription;
use App\Models\User;
use App\Models\Visit;
use Database\Seeders\MedicineCatalogSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class ClinicWorkflowTest extends TestCase
{
    use RefreshDatabase;

    public function test_doctor_calling_waiting_patient_saves_assignment_and_call_time(): void
    {
        $doctor = User::factory()->create(['role' => 'dokter']);
        $visit = Visit::factory()->create(['status' => 'menunggu_dokter']);

        $response = $this->actingAs($doctor)->patch('/visits/'.$visit->id.'/status', [
            'status' => 'dipanggil',
        ]);

        $response->assertRedirect(route('dashboard'));
        $this->assertDatabaseHas('visits', [
            'id' => $visit->id,
            'status' => 'dipanggil',
            'assigned_doctor_id' => $doctor->id,
        ]);
        $this->assertNotNull($visit->fresh()->called_at);
    }

    public function test_doctor_can_submit_multiple_medicines_in_one_prescription(): void
    {
        $this->seed(MedicineCatalogSeeder::class);
        $doctor = User::factory()->create(['role' => 'dokter']);
        $visit = Visit::factory()->create([
            'assigned_doctor_id' => $doctor->id,
            'status' => 'konsultasi',
        ]);
        $medicines = Medicine::query()->whereIn('name', ['Paracetamol', 'Vitamin C'])->get()->keyBy('name');

        $response = $this->actingAs($doctor)->post(route('visits.prescriptions.store', $visit), [
            'items' => [
                [
                    'medicine_id' => $medicines->get('Paracetamol')->id,
                    'quantity' => 2,
                    'dosage' => 'Sesuai instruksi dokter',
                ],
                [
                    'medicine_id' => $medicines->get('Vitamin C')->id,
                    'quantity' => 1,
                    'dosage' => 'Sesuai instruksi dokter',
                ],
            ],
        ]);

        $response->assertRedirect(route('dashboard'));
        $this->assertDatabaseCount('prescription_items', 2);
        $this->assertDatabaseHas('prescription_items', [
            'medicine_id' => $medicines->get('Paracetamol')->id,
            'quantity' => 2,
        ]);
        $this->assertDatabaseHas('prescription_items', [
            'medicine_id' => $medicines->get('Vitamin C')->id,
            'quantity' => 1,
        ]);
    }

    public function test_nurse_dashboard_shows_full_patient_data_and_complaint_for_todays_visits_only(): void
    {
        $this->travelTo(now()->setTime(9, 0));
        $nurse = User::factory()->create(['role' => 'suster']);
        $patient = User::factory()->create([
            'name' => 'Pasien Hari Ini',
            'role' => 'pasien',
            'phone' => '081234567890',
            'national_id' => '3175091201990001',
            'national_id_hash' => User::nationalIdHash('3175091201990001'),
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Kesehatan No. 10',
            'emergency_contact_name' => 'Keluarga Pasien',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'O+',
            'medical_history' => 'Alergi udang',
        ]);
        Visit::factory()->create([
            'patient_id' => $patient->id,
            'queue_number' => '1A',
            'queue_date' => today(),
            'complaint' => 'Demam sejak pagi',
            'service' => 'Poli Umum',
        ]);
        Visit::factory()->create([
            'patient_id' => User::factory()->create([
                'name' => 'Pasien Kemarin',
                'role' => 'pasien',
            ])->id,
            'queue_number' => '9G',
            'queue_date' => today()->subDay(),
            'complaint' => 'Kunjungan hari sebelumnya',
        ]);

        $response = $this->actingAs($nurse)->get(route('dashboard.workflow'));

        $response->assertOk()
            ->assertSee('Pasien Hari Ini')
            ->assertSee('1A')
            ->assertSee('Demam sejak pagi')
            ->assertSee('3175091201990001')
            ->assertSee('081234567890')
            ->assertSee('12 Jan 1999')
            ->assertSee('Perempuan')
            ->assertSee('Jl. Kesehatan No. 10')
            ->assertSee('Keluarga Pasien')
            ->assertSee('081298765432')
            ->assertSee('O+')
            ->assertSee('Alergi udang')
            ->assertDontSee('Pasien Kemarin')
            ->assertDontSee('Kunjungan hari sebelumnya');

        $doctor = User::factory()->create(['role' => 'dokter']);
        $this->actingAs($doctor)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertDontSee('3175091201990001')
            ->assertDontSee('Alergi udang');
    }

    public function test_patient_to_pharmacy_workflow_keeps_prescription_details_private_from_patient(): void
    {
        $this->seed(MedicineCatalogSeeder::class);
        $patient = User::factory()->create(['name' => 'Pasien Alur', 'role' => 'pasien']);
        $nurse = User::factory()->create(['name' => 'Perawat Alur', 'role' => 'suster']);
        $doctor = User::factory()->create(['name' => 'Dokter Alur', 'role' => 'dokter']);
        $pharmacist = User::factory()->create(['name' => 'Apoteker Alur', 'role' => 'apoteker']);

        $this->actingAs($patient)->post('/visits', [
            'service' => 'Poli Umum',
            'complaint' => 'Pemeriksaan rutin',
        ])->assertRedirect(route('dashboard'));

        $visit = Visit::query()->whereBelongsTo($patient, 'patient')->firstOrFail();
        $this->assertSame('menunggu_dokter', $visit->status);
        $this->assertSame('Poli Umum', $visit->service);
        $this->assertSame('1A', $visit->queue_number);

        $this->actingAs($patient)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('1A')
            ->assertSee('Perkiraan panggilan:')
            ->assertSee('Anda berikutnya')
            ->assertDontSee('Antrean dan data pasien');

        $nurseResponse = $this->actingAs($nurse)->get(route('dashboard.workflow'));
        $nurseResponse->assertOk()
            ->assertSee('Pasien Alur')
            ->assertSee('Pemeriksaan rutin')
            ->assertDontSee('Terima data pasien');
        $this->patch('/visits/'.$visit->id.'/status', ['status' => 'menunggu_dokter'])
            ->assertForbidden();
        $this->assertDatabaseHas('visits', ['id' => $visit->id, 'status' => 'menunggu_dokter']);

        $medicine = Medicine::query()->where('name', 'Paracetamol')->firstOrFail();
        $this->actingAs($doctor)->get(route('dashboard.workflow'))
            ->assertSee('Pasien Alur')
            ->assertSee('Panggil pasien');
        $this->patch('/visits/'.$visit->id.'/status', ['status' => 'dipanggil'])
            ->assertRedirect(route('dashboard'));
        $this->assertNotNull($visit->fresh()->called_at);
        $this->actingAs($patient)->get(route('dashboard.workflow'))
            ->assertSee('Dokter sedang memanggil Anda')
            ->assertSee('Silakan menuju ruang pemeriksaan.');
        $this->actingAs($doctor);
        $this->patch('/visits/'.$visit->id.'/status', ['status' => 'konsultasi'])
            ->assertRedirect(route('dashboard'));
        $this->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('Tambah obat')
            ->assertSee('1 dari 10 jenis obat')
            ->assertSee('data-max-prescription-items="10"', false);
        $this->post('/visits/'.$visit->id.'/prescriptions', [
            'items' => [[
                'medicine_id' => $medicine->id,
                'quantity' => 2,
                'dosage' => 'Aturan pakai sesuai pemeriksaan',
            ], [
                'medicine_id' => Medicine::query()->where('name', 'Vitamin C')->value('id'),
                'quantity' => 3,
                'dosage' => 'Satu kali sehari',
            ]],
        ])->assertRedirect(route('dashboard'));

        $prescription = Prescription::query()->whereBelongsTo($visit)->firstOrFail();
        $this->assertDatabaseCount('prescription_items', 2);
        $this->patch('/visits/'.$visit->id.'/status', ['status' => 'selesai'])
            ->assertRedirect(route('dashboard'));

        $this->actingAs($pharmacist)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('Paracetamol')
            ->assertSee('Vitamin C')
            ->assertSee('Aturan pakai sesuai pemeriksaan')
            ->assertSee('Satu kali sehari');
        $this->post(route('prescriptions.process', $prescription))
            ->assertRedirect(route('dashboard'));
        $this->assertDatabaseHas('medicines', ['id' => $medicine->id, 'stock' => 98]);
        $this->assertDatabaseHas('medicines', ['name' => 'Vitamin C', 'stock' => 97]);

        $this->patch('/prescriptions/'.$prescription->id.'/status', ['status' => 'siap_diambil'])
            ->assertRedirect(route('dashboard'));
        $payment = Payment::query()->whereBelongsTo($visit)->firstOrFail();
        $this->assertSame('12000.00', $payment->amount);

        $this->actingAs($patient)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('Pasien Alur')
            ->assertSee('Obat siap diambil di apotek.')
            ->assertSee('melakukan pembayaran')
            ->assertSee('Rp 12.000')
            ->assertDontSee('Paracetamol')
            ->assertDontSee('Aturan pakai sesuai pemeriksaan')
            ->assertDontSee('Resep tersimpan')
            ->assertDontSee('Resep')
            ->assertDontSee('Keluar');

        $this->actingAs($pharmacist)->post(route('payments.record', $payment))
            ->assertRedirect(route('dashboard'));
        $this->patch('/prescriptions/'.$prescription->id.'/status', ['status' => 'diserahkan'])
            ->assertRedirect(route('dashboard'));

        $this->actingAs($patient)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('Pengambilan obat selesai.')
            ->assertSee('Lunas')
            ->assertDontSee('Paracetamol');
        $this->get(route('dashboard'))
            ->assertDontSee('Resep')
            ->assertDontSee('Keluar');
    }

    public function test_patient_call_estimate_includes_earlier_active_visits_in_the_same_poli(): void
    {
        $patientAhead = User::factory()->create(['role' => 'pasien']);
        $patientWaiting = User::factory()->create(['role' => 'pasien']);
        $aheadVisit = Visit::factory()->create([
            'patient_id' => $patientAhead->id,
            'service' => 'Poli Gigi',
            'queue_number' => '1G',
            'queue_sequence' => 1,
            'queue_date' => now()->toDateString(),
            'status' => 'menunggu_dokter',
        ]);
        Visit::factory()->create([
            'patient_id' => $patientWaiting->id,
            'service' => 'Poli Gigi',
            'queue_number' => '2G',
            'queue_sequence' => 2,
            'queue_date' => now()->toDateString(),
            'status' => 'menunggu_dokter',
        ]);

        $response = $this->actingAs($patientWaiting)->get(route('dashboard.workflow'));

        $response->assertOk()->assertSee('1 antrean sebelum Anda');
        $this->assertSame(1, $aheadVisit->queue_sequence);
    }

    public function test_queue_number_sequence_is_separate_per_clinic_and_resets_for_each_date(): void
    {
        $patient = User::factory()->create(['role' => 'pasien']);

        $this->actingAs($patient)->post('/visits', ['service' => 'Poli Umum'])
            ->assertRedirect(route('dashboard'));
        $this->post('/visits', ['service' => 'Poli Gigi'])
            ->assertRedirect(route('dashboard'));
        $this->post('/visits', ['service' => 'Poli Umum'])
            ->assertRedirect(route('dashboard'));
        $this->post('/visits', ['service' => 'Poli KIA'])
            ->assertRedirect(route('dashboard'));

        $this->assertDatabaseHas('visits', ['service' => 'Poli Umum', 'queue_number' => '1A', 'queue_sequence' => 1]);
        $this->assertDatabaseHas('visits', ['service' => 'Poli Umum', 'queue_number' => '2A', 'queue_sequence' => 2]);
        $this->assertDatabaseHas('visits', ['service' => 'Poli Gigi', 'queue_number' => '1G', 'queue_sequence' => 1]);
        $this->assertDatabaseHas('visits', ['service' => 'Poli KIA', 'queue_number' => '1K', 'queue_sequence' => 1]);

        $this->travelTo(now()->addDay());
        $this->post('/visits', ['service' => 'Poli Umum'])->assertRedirect(route('dashboard'));
        $tomorrowVisit = Visit::query()
            ->where('service', 'Poli Umum')
            ->where('queue_sequence', 1)
            ->whereDate('queue_date', now()->toDateString())
            ->firstOrFail();
        $this->assertSame('1A', $tomorrowVisit->queue_number);
    }

    public function test_patient_dashboard_has_scrollable_history_of_completed_and_cancelled_visits_only(): void
    {
        $patient = User::factory()->create(['role' => 'pasien']);
        $completedVisit = Visit::factory()->create([
            'patient_id' => $patient->id,
            'queue_number' => '1A',
            'status' => 'selesai',
            'service' => 'Poli Umum',
        ]);
        $cancelledVisit = Visit::factory()->create([
            'patient_id' => $patient->id,
            'queue_number' => '1G',
            'status' => 'dibatalkan',
            'service' => 'Poli Gigi',
        ]);
        Visit::factory()->create([
            'patient_id' => $patient->id,
            'queue_number' => '2A',
            'status' => 'menunggu_dokter',
        ]);

        $this->actingAs($patient)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertSee('Riwayat pasien')
            ->assertSee('Daftar riwayat kunjungan pasien')
            ->assertSee('1A')
            ->assertSee('1G');

        $this->assertSame(2, $completedVisit->newQuery()->whereIn('status', ['selesai', 'dibatalkan'])->where('patient_id', $patient->id)->count());
        $this->assertDatabaseHas('visits', ['id' => $cancelledVisit->id, 'status' => 'dibatalkan']);
    }

    public function test_catalog_includes_ten_additional_medicines_without_changing_existing_stock(): void
    {
        $this->seed(MedicineCatalogSeeder::class);

        $this->assertSame(17, Medicine::query()->count());
        $this->assertSame(6, Medicine::query()->where('stock', 100)->count());
        $this->assertDatabaseHas('medicines', [
            'name' => 'Ambroxol Sirup',
            'stock' => 2,
        ]);
        $this->assertDatabaseHas('medicines', [
            'name' => 'Ibuprofen',
            'strength' => '200 mg',
            'stock' => 50,
        ]);
        $this->assertDatabaseHas('medicines', [
            'name' => 'Antasida',
            'form' => 'Tablet kunyah',
            'stock' => 60,
        ]);
        $this->assertDatabaseHas('medicines', [
            'name' => 'Asam Mefenamat',
            'strength' => '500 mg',
            'stock' => 50,
        ]);
    }

    public function test_pharmacist_cannot_allocate_insufficient_stock_and_can_restock_and_retry(): void
    {
        $this->seed(MedicineCatalogSeeder::class);
        $patient = User::factory()->create(['role' => 'pasien']);
        $doctor = User::factory()->create(['role' => 'dokter']);
        $pharmacist = User::factory()->create(['role' => 'apoteker']);
        $visit = Visit::factory()->create([
            'patient_id' => $patient->id,
            'status' => 'konsultasi',
            'assigned_doctor_id' => $doctor->id,
        ]);
        $lowStockMedicine = Medicine::query()->where('name', 'Ambroxol Sirup')->firstOrFail();
        $prescription = $visit->prescription()->create([
            'doctor_id' => $doctor->id,
            'medicine' => 'Resep terstruktur',
        ]);
        $prescription->items()->create([
            'medicine_id' => $lowStockMedicine->id,
            'quantity' => 3,
            'dosage' => 'Sesuai instruksi dokter',
            'unit_price' => $lowStockMedicine->unit_price,
        ]);

        $this->actingAs($pharmacist)->post(route('prescriptions.process', $prescription))
            ->assertRedirect(route('dashboard'))
            ->assertSessionHas('error');
        $this->assertDatabaseHas('medicines', ['id' => $lowStockMedicine->id, 'stock' => 2]);
        $this->assertDatabaseHas('prescriptions', ['id' => $prescription->id, 'status' => 'stok_tidak_cukup']);
        $this->assertDatabaseMissing('payments', ['visit_id' => $visit->id]);

        $this->patch(route('medicines.stock', $lowStockMedicine), ['quantity' => 5])
            ->assertRedirect(route('dashboard'));
        $this->post(route('prescriptions.process', $prescription))
            ->assertRedirect(route('dashboard'));

        $this->assertDatabaseHas('medicines', ['id' => $lowStockMedicine->id, 'stock' => 4]);
        $this->assertDatabaseHas('prescriptions', ['id' => $prescription->id, 'status' => 'diproses']);
    }

    public function test_pharmacist_can_add_a_medicine_and_restock_it(): void
    {
        $pharmacist = User::factory()->create(['role' => 'apoteker']);

        $response = $this->actingAs($pharmacist)->post(route('medicines.store'), [
            'name' => 'Medicine Baru',
            'form' => 'Tablet',
            'strength' => '250 mg',
            'unit' => 'tablet',
            'stock' => 10,
            'unit_price' => 2500,
        ]);

        $response->assertRedirect(route('dashboard'))
            ->assertSessionHas('success');
        $this->assertDatabaseHas('medicines', [
            'name' => 'Medicine Baru',
            'form' => 'Tablet',
            'strength' => '250 mg',
            'unit' => 'tablet',
            'stock' => 10,
            'unit_price' => '2500.00',
            'is_active' => true,
        ]);

        $medicine = Medicine::query()->where('name', 'Medicine Baru')->firstOrFail();
        $this->patch(route('medicines.stock', $medicine), ['quantity' => 5])
            ->assertRedirect(route('dashboard'));
        $this->assertDatabaseHas('medicines', ['id' => $medicine->id, 'stock' => 15]);
    }

    public function test_non_pharmacist_cannot_add_medicines(): void
    {
        $doctor = User::factory()->create(['role' => 'dokter']);

        $this->actingAs($doctor)->post(route('medicines.store'), [
            'name' => 'Obat Terlarang',
            'form' => 'Tablet',
            'strength' => '100 mg',
            'unit' => 'tablet',
            'stock' => 10,
            'unit_price' => 1000,
        ])->assertForbidden();

        $this->assertDatabaseMissing('medicines', ['name' => 'Obat Terlarang']);
    }

    public function test_patient_cannot_see_another_patients_visit_or_prescription(): void
    {
        $owner = User::factory()->create(['role' => 'pasien']);
        $otherPatient = User::factory()->create(['role' => 'pasien']);
        $doctor = User::factory()->create(['role' => 'dokter']);
        $visit = Visit::factory()->create([
            'patient_id' => $owner->id,
            'assigned_doctor_id' => $doctor->id,
            'status' => 'konsultasi',
        ]);
        $prescription = $visit->prescription()->create([
            'doctor_id' => $doctor->id,
            'medicine' => 'Resep rahasia',
        ]);
        $medicine = Medicine::factory()->create(['name' => 'Obat Rahasia Pasien Lain']);
        $prescription->items()->create([
            'medicine_id' => $medicine->id,
            'quantity' => 1,
            'dosage' => 'Aturan rahasia',
            'unit_price' => $medicine->unit_price,
        ]);

        $this->actingAs($otherPatient)->get(route('dashboard.workflow'))
            ->assertOk()
            ->assertDontSee($visit->queue_number)
            ->assertDontSee('Obat Rahasia Pasien Lain')
            ->assertDontSee('Aturan rahasia');
        $this->patch('/visits/'.$visit->id.'/status', ['status' => 'dibatalkan'])
            ->assertForbidden();
    }

    public function test_only_pharmacists_can_change_prescription_or_payment_status(): void
    {
        $patient = User::factory()->create(['role' => 'pasien']);
        $doctor = User::factory()->create(['role' => 'dokter']);
        $visit = Visit::factory()->create([
            'patient_id' => $patient->id,
            'assigned_doctor_id' => $doctor->id,
            'status' => 'selesai',
        ]);
        $prescription = $visit->prescription()->create([
            'doctor_id' => $doctor->id,
            'medicine' => 'Resep terstruktur',
            'status' => 'siap_diambil',
        ]);
        $payment = $visit->payment()->create(['amount' => 1000, 'status' => 'belum_bayar']);

        $this->actingAs($patient)->post(route('payments.record', $payment))->assertForbidden();
        $this->patch('/prescriptions/'.$prescription->id.'/status', ['status' => 'diserahkan'])->assertForbidden();

        $this->assertDatabaseHas('payments', ['id' => $payment->id, 'status' => 'belum_bayar']);
        $this->assertDatabaseHas('prescriptions', ['id' => $prescription->id, 'status' => 'siap_diambil']);
    }

    public function test_profile_only_updates_real_account_data_and_changes_password_safely(): void
    {
        $nationalId = '3201234567890001';
        $user = User::factory()->create([
            'name' => 'Nama Sebelum',
            'phone' => '081200000000',
            'role' => 'pasien',
            'national_id' => $nationalId,
            'national_id_hash' => User::nationalIdHash($nationalId),
            'date_of_birth' => '1990-01-01',
            'gender' => 'Laki-laki',
            'address' => 'Alamat sebelum',
            'emergency_contact_name' => 'Kontak Sebelum',
            'emergency_contact_phone' => '081211111111',
        ]);

        $this->actingAs($user)->get('/profile')
            ->assertOk()
            ->assertSee('Nama Sebelum')
            ->assertDontSee('password123')
            ->assertSee($nationalId)
            ->assertSee('Nama kontak darurat');
        $this->get('/profile')
            ->assertSee('Data pengguna')
            ->assertSee('Data akun')
            ->assertSee('Keluar');

        $this->put('/profile', [
            'name' => 'Nama Sesudah',
            'email' => $user->email,
            'phone' => '081299999999',
            'national_id' => $nationalId,
            'date_of_birth' => '1990-01-01',
            'gender' => 'Laki-laki',
            'address' => 'Alamat sesudah',
            'emergency_contact_name' => 'Kontak Sesudah',
            'emergency_contact_phone' => '081222222222',
            'blood_type' => 'B+',
        ])->assertRedirect(route('profile'));

        $this->assertDatabaseHas('users', [
            'id' => $user->id,
            'name' => 'Nama Sesudah',
            'phone' => '081299999999',
            'national_id_hash' => User::nationalIdHash($nationalId),
            'address' => 'Alamat sesudah',
            'emergency_contact_name' => 'Kontak Sesudah',
            'emergency_contact_phone' => '081222222222',
            'blood_type' => 'B+',
        ]);
        $this->assertSame($nationalId, $user->fresh()->national_id);

        $this->post('/logout')->assertRedirect(route('landing'));
        $this->get('/login')->assertOk()->assertSee('Ubah kata sandi');
        $this->post('/login/password', [
            'email' => $user->email,
            'role' => 'pasien',
            'current_password' => 'password-salah',
            'password' => 'NewSecurePass2026!',
            'password_confirmation' => 'NewSecurePass2026!',
        ])->assertSessionHasErrors('current_password');

        $this->post('/login/password', [
            'email' => $user->email,
            'role' => 'pasien',
            'current_password' => 'password',
            'password' => 'NewSecurePass2026!',
            'password_confirmation' => 'NewSecurePass2026!',
        ])->assertRedirect(route('login'));

        $this->assertTrue(Hash::check('NewSecurePass2026!', $user->fresh()->password));
    }

    public function test_staff_password_change_requires_role_registration_code_from_login(): void
    {
        Config::set('clinic.registration_codes.dokter', 'kode-dokter-demo');
        $doctor = User::factory()->create(['role' => 'dokter']);

        $this->post('/login/password', [
            'email' => $doctor->email,
            'role' => 'dokter',
            'current_password' => 'password',
            'password' => 'NewSecurePass2026!',
            'password_confirmation' => 'NewSecurePass2026!',
        ])->assertSessionHasErrors('registration_code');

        $this->assertTrue(Hash::check('password', $doctor->fresh()->password));

        $this->post('/login/password', [
            'email' => $doctor->email,
            'role' => 'dokter',
            'registration_code' => 'kode-dokter-demo',
            'current_password' => 'password',
            'password' => 'NewSecurePass2026!',
            'password_confirmation' => 'NewSecurePass2026!',
        ])->assertRedirect(route('login'));

        $this->assertTrue(Hash::check('NewSecurePass2026!', $doctor->fresh()->password));
    }
}
