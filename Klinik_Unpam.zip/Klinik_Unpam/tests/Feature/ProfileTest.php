<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProfileTest extends TestCase
{
    use RefreshDatabase;

    public function test_patient_profile_displays_complete_patient_data(): void
    {
        $patient = User::factory()->create([
            'role' => 'pasien',
            'national_id' => '3175091201990001',
            'national_id_hash' => User::nationalIdHash('3175091201990001'),
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Kesehatan No. 10',
            'emergency_contact_name' => 'Keluarga Pasien',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'O+',
            'medical_history' => 'Alergi udang',
        ]);

        $response = $this->actingAs($patient)->get(route('profile'));

        $response->assertOk()
            ->assertSee('Data pengguna')
            ->assertSee('name="national_id" value="3175091201990001"', false)
            ->assertSee('name="date_of_birth" value="1999-01-12"', false)
            ->assertSee('Perempuan')
            ->assertSee('Jl. Kesehatan No. 10')
            ->assertSee('Keluarga Pasien')
            ->assertSee('081298765432')
            ->assertSee('O+')
            ->assertSee('Alergi udang')
            ->assertSee('name="medical_history"', false);
        $this->assertArrayNotHasKey('national_id', $patient->toArray());
    }

    public function test_patient_can_update_complete_personal_and_emergency_contact_data(): void
    {
        $patient = User::factory()->create([
            'role' => 'pasien',
            'national_id' => '3175091201990001',
            'national_id_hash' => User::nationalIdHash('3175091201990001'),
        ]);
        $updatedNationalId = '3175091201990002';

        $response = $this->actingAs($patient)->put(route('profile.update'), [
            'name' => 'Pasien Diperbarui',
            'email' => 'pasien-baru@example.com',
            'phone' => '081234567890',
            'national_id' => $updatedNationalId,
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Klinik No. 20',
            'emergency_contact_name' => 'Kontak Baru',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'A+',
            'medical_history' => 'Asma sejak kecil',
        ]);

        $response->assertRedirect(route('profile'));
        $this->assertDatabaseHas('users', [
            'id' => $patient->id,
            'name' => 'Pasien Diperbarui',
            'email' => 'pasien-baru@example.com',
            'phone' => '081234567890',
            'national_id_hash' => User::nationalIdHash($updatedNationalId),
            'gender' => 'Perempuan',
            'address' => 'Jl. Klinik No. 20',
            'emergency_contact_name' => 'Kontak Baru',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'A+',
            'medical_history' => 'Asma sejak kecil',
        ]);
        $this->assertSame($updatedNationalId, $patient->fresh()->national_id);
        $this->assertSame('1999-01-12', $patient->fresh()->date_of_birth->format('Y-m-d'));
    }

    public function test_patient_cannot_update_to_a_national_id_already_used_by_another_account(): void
    {
        $patient = User::factory()->create([
            'role' => 'pasien',
            'national_id' => '3175091201990001',
            'national_id_hash' => User::nationalIdHash('3175091201990001'),
        ]);
        $existingPatient = User::factory()->create([
            'role' => 'pasien',
            'national_id' => '3175091201990002',
            'national_id_hash' => User::nationalIdHash('3175091201990002'),
        ]);

        $response = $this->actingAs($patient)->from(route('profile'))->put(route('profile.update'), [
            'name' => $patient->name,
            'email' => $patient->email,
            'phone' => $patient->phone,
            'national_id' => '3175091201990002',
            'date_of_birth' => '1999-01-12',
            'gender' => 'Perempuan',
            'address' => 'Jl. Klinik No. 20',
            'emergency_contact_name' => 'Kontak Baru',
            'emergency_contact_phone' => '081298765432',
            'blood_type' => 'A+',
        ]);

        $response->assertRedirect(route('profile'))->assertSessionHasErrors('national_id');
        $this->assertSame('3175091201990001', $patient->fresh()->national_id);
        $this->assertSame('3175091201990002', $existingPatient->fresh()->national_id);
    }

    public function test_staff_profile_shows_staff_information_without_patient_only_fields(): void
    {
        $doctor = User::factory()->create([
            'role' => 'dokter',
            'staff_number' => 'DOK-1001',
        ]);

        $this->actingAs($doctor)->get(route('profile'))
            ->assertOk()
            ->assertSee('DOK-1001')
            ->assertSee($doctor->email)
            ->assertDontSee('Nama kontak darurat')
            ->assertDontSee('Golongan darah');
    }

    public function test_profile_provides_dashboard_return_and_logout_controls(): void
    {
        $user = User::factory()->create(['role' => 'dokter']);

        $this->actingAs($user)->get(route('profile'))
            ->assertOk()
            ->assertSee('href="'.route('dashboard').'"', false)
            ->assertSee('Kembali')
            ->assertSee('action="'.route('logout').'"', false)
            ->assertSee('Keluar')
            ->assertDontSee('Dashboard utama')
            ->assertDontSee('Landing page');
    }
}
